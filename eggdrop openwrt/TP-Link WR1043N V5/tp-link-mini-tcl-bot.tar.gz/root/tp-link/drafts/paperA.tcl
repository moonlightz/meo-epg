proc paperA {n} {
   set w [expr {sqrt(10000/(pow(2,$n) * sqrt(2)))}] ;    set h [expr {$w * sqrt(2)}] ;    format "%.2f %.2f" $h $w  
}
