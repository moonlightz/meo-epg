if {![info exists executado]} {set executado 0}
	if {[info exists nid]} {
		if {$nid} {
			foreach c $lcanais {
				putnow "JOIN $c"
			}
		unset c
	}
}
#Tuesday 22:14
switch -glob -- [strftime "%A %H:%M"] {
	"Tuesday 22:00" - "Tuesday 22:00" - "Friday 22:55" - "Friday 22:56" {
	#saca a chave sorteada, gera apostas e compara
		set em [string map {"\t" ""} [exec wget -q -O - http://www.jogossantacasa.pt/web/SCCartazResult/]]
		set chavesorteada [lindex [regexp -inline {<ul class="colums">\n<li>(.*?)</li>} $em] 1]
		putnow "privmsg #konoha :[lindex [regexp -inline {<span class="dataInfo">(.*?)<br>} $em] 1] => $chavesorteada"
		set ganhou "nao"
		set maxapostas 300
		putnow "privmsg #konoha :A gerar $maxapostas apostas e a comparar..."
		for {set nemgen 1} {$nemgen<=$maxapostas} {incr nemgen} {
			set aposta "[emgen 50 5] + [emgen 12 2]"
			#putnow "privmsg moonlight2 :$aposta"
			if {$chavesorteada==$aposta} {
				set ganhou "sim"
				break
			}
		}
		if {$ganhou=="nao"} {
			putnow "privmsg #konoha :Não ganhei o primeiro prémio. :-("
		} else {
			putnow "privmsg #konoha :Ganhei o primeiro prémio! :-)"
		}
		unset em chavesorteada ganhou aposta
	}

	"*23:00" - "*23:01" - "*11:00" - "*11:01" {
	#Faz o backup automático comprimindo a dir do bot e depois manda para o raspberrypi
		if {!$executado} {
			set texto "$botnick backup"
			set executado 1
		}
	}
	"*00:00" - "*00:01" - "*06:46" {
	#Copia $fichlog para ${fichlog}.yesterday e reinicia $fichlog
		if {!$executado} {
			file copy -force $fichlog ${fichlog}.yesterday
			set fich [open $fichlog w+]
			close $fich
			set executado 1
		}
	}
	"Sunday 11:18" - "Sunday 11:19" {
	#Corre opkg update à procura de actualizações de pacotes para o OpenWRT
		if {!$executado} {
			set texto "opkg update"
			set canal [lindex $lcanais 0]
			set executado 1
		}
	}
	default { 
		set executado 0
	}
}
set dscript(tarefas.tcl) "Lista de tarefas"
#a verificacao do html do releases openwrt removida a 6/1/2023
#	"*23:56" - "*23:57" {
#	#Exemplo básico de uma tarefa a mostrar texto no canal
#		if {!$executado} {
#			putnow "PRIVMSG #konoha :Ring-Ring, Beep-Beep, uh-uh"
#			set executado 1
#		}
#	}
