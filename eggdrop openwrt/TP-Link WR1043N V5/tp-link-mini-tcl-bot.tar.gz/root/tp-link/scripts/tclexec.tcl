proc tp:tcl {quem chan cmd} {
	if {[catch {uplevel #0 $cmd} out]} {
		foreach l [split $out "\n"] {
			putnow "PRIVMSG $chan :Erro Tcl: [tr $l]"
		}
		if {[string index $chan 0]=="#"} {
			set msgmec "NOTICE"
		} else {
			set msgmec "PRIVMSG"
		}
		foreach l [split $::errorInfo "\n"] {

			putnow "$msgmec $quem :\0038,4>>\003 $l"
		}
	} else {
		if {$out==""} {set out "Feito."}
		foreach l [split $out "\n"] {
			for {set iout 0} {$iout<=[string length $l]} {incr iout 439} {
				putnow "PRIVMSG $chan :Tcl: [tr [string range $l $iout $iout+438]]"
			}
		}
	}
	return 0
}


if {[string range $texto 0 3]=="tcl "} {
	if {[users "$quem!$uhost"]} {
		tp:tcl $quem $canal [string range $texto 4 end]
	} else {
		putnow "PRIVMSG $canal :Quem és tu?"
	}
}
set dscript(tclexec.tcl) "Executa comandos tcl"
