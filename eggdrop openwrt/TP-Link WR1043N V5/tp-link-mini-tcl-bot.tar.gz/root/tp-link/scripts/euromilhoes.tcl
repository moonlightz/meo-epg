proc emgen {max elem} {
	for {set a 1} {$a<=$max} {incr a} {
		lappend tomb $a
	}

	for {set b 1} {$b<=$elem} {incr b} { 
		for {set a 1} {$a<10} {incr a} {
			set n 1
			set stomb {}
			foreach item $tomb {
				set index [expr {int(rand() * $n)}]
				set stomb [linsert $stomb $index $item]
				incr n
			}
			set tomb $stomb
		}
		set index [expr {int(rand() * [llength $tomb])}]
		lappend res [lindex $tomb $index]
		set tomb [lreplace $tomb $index $index]
	}
	return [lsort -integer $res]
}

proc tp:euromilhoes {quem canal text} {
	if {$text==""} {set b 1} {set b $text}
	for {set a 1} {$a<=$b} {incr a} {
		set numeros [emgen 50 5]
		set estrelas [emgen 12 2]
		putnow "privmsg $canal :$numeros - $estrelas"
	}
}

bind euromilhoes tp:euromilhoes
set dscript(euromilhoes.tcl) "euromilhoes"
