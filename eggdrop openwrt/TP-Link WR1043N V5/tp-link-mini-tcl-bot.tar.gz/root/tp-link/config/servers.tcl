set server(1) {irc.libera.chat0 6667}
set server(2) {192.168.1.250 60001 tplink:111111}
