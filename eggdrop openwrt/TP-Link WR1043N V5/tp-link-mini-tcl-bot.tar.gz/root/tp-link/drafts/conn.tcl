set host "ie.ptchat.org"
set port 6667
set timeout 10000 ;# in milliseconds, i.e., 10 seconds

set sock [socket $host $port]
fconfigure $sock -blocking 0

set cancel_id [after $timeout {
    catch {
        close $sock
    }
}]

if {[catch {fblocked $sock}]} {
    # The socket is not ready for I/O yet.
    # Wait for it to become ready or to timeout.
    vwait forever
} else {
    # The socket is ready for I/O, so cancel the timeout.
    after cancel $cancel_id
    # Use the socket as needed...
}
