proc tclLog {string} {

	catch {puts stderr $string}
    
}
