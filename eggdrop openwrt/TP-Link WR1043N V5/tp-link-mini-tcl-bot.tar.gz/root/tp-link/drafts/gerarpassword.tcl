proc gerarpassword {comprimento} {
set chars "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789" ; set password ""; while {[string length $password] < $comprimento} {    append password [string index $chars [expr {int(rand()*[string length $chars])}]]}; return $password
}
