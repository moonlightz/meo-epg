# Calculadora

proc decimalScale {number factor} {

    # Validate factor format 0.xxx
    if {![regexp {^0\.([0-9]+)$} $factor -> frac]} {
        error "Factor must be of form 0.xxx"
    }

    # How many digits after decimal?
    set shift [string length $frac]

    # Remove leading + if present
    regsub {^\+} $number {} number

    # Only integer input supported here
    if {[string first "." $number] != -1} {
        error "Number must be integer"
    }

    set len [string length $number]

    if {$shift >= $len} {
        # Need leading zeros
        set zerosNeeded [expr {$shift - $len}]
        set result "0.[string repeat 0 $zerosNeeded]$number"
    } else {
        set splitPos [expr {$len - $shift}]
        set left  [string range $number 0 [expr {$splitPos - 1}]]
        set right [string range $number $splitPos end]
        set result "$left.$right"
    }

    # Trim trailing zeros
    regsub {\.?0+$} $result {} result

    return $result
}


proc cmul {canal num1 num2} {

	set n1f [string length [lindex [split $num1 .] 1]]
	set n2f [string length [lindex [split $num2 .] 1]]

	set nnum1 [string trimleft [string trimleft [string map {. ""} $num1] 0] ?]
	set nnum2 [string trimleft [string trimleft [string map {. ""} $num2] 0] ?]

	if {$nnum1==""} {set nnum1 0}
	if {$nnum2==""} {set nnum2 0}

	if {$nnum2>9 && [regexp {0+$} $nnum2 zeros]} {
		append nnum1 [string repeat " " [string length $zeros]]
	}

	set linha 3
	set despzeros 1

	set s(1) $nnum1
	set s(2) $nnum2
	set s(3) ""
	for {set n2i [expr [string length $nnum2]-1]} {$n2i>=0+[string match "-*" $nnum2]} {incr n2i -1} {
		set j [string index $nnum2 $n2i]
		#if {$j==" "} {break}
		if {$j!=0} {
			set despzeros 0
		} else {
			if {$despzeros} {
				set s($linha) 0$s($linha)
				continue
			} else {
				set s($linha) " $s($linha)"
				continue
			}
		}
		set founddigito 0
		set dezenas 0
		
		for {set n1i [expr [string length $nnum1]-1]} {$n1i>=0+[string match "-*" $nnum1]} {incr n1i -1} {
			set i [string index $nnum1 $n1i]
			if {$i==" "} {
				if {!$founddigito} {
					continue
				} else {
					break
				}
			}
			set st [expr $j*$i+$dezenas]
			lassign [split [format %02d $st] ""] dezenas unidades
			set s($linha) $unidades$s($linha)
		}

		if {$dezenas!="0"} {
			set s($linha) $dezenas$s($linha)
		}
	
		if {$n2i>0+[string match "-*" $nnum2]} {
			if {$i!=0} {incr linha}
			set s($linha) [string repeat " " [expr [string length $nnum2]-$n2i]]
		}

	}


#	putnow "privmsg $canal :[format "%*s" 10 $nnum1]"
#	putnow "privmsg $canal :\037[string replace [format "%*s" 10 $nnum2] 0 0 x]"
	set compr 0

	if {$linha>3} {
		incr linha
		set s($linha) 0
		foreach i [lrange "0 [lsort -integer [array names s]]" 3 end-1] {
			set s($linha) [expr $s($linha)+[if {[string match "-*" $nnum1]||[string match "-*" $nnum2]} {set a "-"}][string map {" " 0} $s($i)]]
		}
	}
	foreach linha [array names s] {
		if {[string length $s($linha)]>$compr} {
			set compr [string length $s($linha)]
		}
	}

	incr compr 2
	set sfim [llength [array names s]]

	for {set i 1} {$i<=$sfim} {incr i} {
putnow "privmsg $canal :[if {$i==2 || $i==[expr $sfim-1]} {set a "\037"}][format "%*s" $compr [if {$i==2} {set a "× "} elseif {$i==[expr [llength [array names s]]-1]} {set a "+ "}]$s($i)][if {$i==2 || $i==[expr [llength [array names s]]-1]} {set a "\037"}]\
		[if {$i==1} {
			if {$n1f>0} {set a "× 0.[string repeat 0 [expr $n1f-1]]1 = $num1"}
		} elseif {$i==2} {
			if {$n2f>0} {set a "× 0.[string repeat 0 [expr $n2f-1]]1 = $num2"}
		} elseif {$i==$sfim} {
			if {$n1f+$n2f>0} {
				set sn12f [expr $n1f+$n2f]
				set stfl "0.[string repeat 0 [expr $sn12f-1]]1"
				set total [decimalScale $s($i) $stfl]
				set a "× $stfl = \002$total\002"
			}
		}]"
		if {$n1f+$n2f==0 && $i==$sfim} {
			set total $s($i)
		}
	}




	set total
}

proc cdiv {canal num1 num2} {
	set precisao 20
	set pos 0
	set nnum1 [string map {. ""} $num1]
	set nnum2 [string trimleft [string map {. ""} $num2] 0]

	set pesquerda(0) $nnum1
	set pdireita(0) $num2

	for {set i 0} {$i<=[string length $num1]} {incr i} {
		set num1 "$num1   "
		incr iprecisao
		if {$iprecisao>$precisao} {break}
	}

	foreach item [array names pesquerda] {
		append tamanho [string length $pesquerda($item)],
	}
	set tamanho [string trimright $tamanho ,]
	set tamanho [expr max($tamanho)]

	foreach item [lsort -integer [array names pesquerda]] {
		putnow "privmsg $canal :[format %-*s $tamanho $pesquerda($item)]  [if {[info exists pdireita($item)]} {if {$item==0} {set a "|\037$pdireita($item) "}}]"
	}
expr $num1/$num2
}

proc cdiv2 {canal num1 num2} {
#	putnow "privmsg $canal :codigo"
#proc long_division {dividend divisor {precision 5}} {}
set dividend $num1
set divisor $num2
set precision 6
    if {$divisor == 0} {
        error "Division by zero"
    }

    # Convert to integers by removing decimal point
    set scale 0
    if {[string match "*.*" $dividend]} {
        set parts [split $dividend "."]
        set scale [string length [lindex $parts 1]]
        set dividend [join $parts ""]
    }

    set divisor_int $divisor
    set remainder 0
    set result ""
    set steps {}

    # Process each digit
    foreach digit [split $dividend ""] {
        set remainder [expr {$remainder * 10 + $digit}]
        set q [expr {$remainder / $divisor_int}]
        set remainder [expr {$remainder % $divisor_int}]

        append result $q
        lappend steps [list $remainder $q]
    }

    # Handle decimal part
    if {$remainder != 0} {
        append result "."
        for {set i 0} {$i < $precision && $remainder != 0} {incr i} {
            set remainder [expr {$remainder * 10}]
            set q [expr {$remainder / $divisor_int}]
            set remainder [expr {$remainder % $divisor_int}]

            append result $q
            lappend steps [list $remainder $q]
        }
    }

    # Print formatted output
    putnow "privmsg $canal :$dividend | $divisor"
    putnow "privmsg $canal :Result: $result"
    putnow "privmsg $canal :Steps:"

    set indent 0
    foreach step $steps {
        lassign $step rem q
        putnow "privmsg $canal :[string repeat " " $indent]$rem    $q"
        incr indent 2
    }



	expr {$num1/$num2}
}

proc csum {canal num1 num2} {
return [expr $num1+$num2]
	if {$num1<0} {set ss1 "-"} {set ss1 " "}
	if {$num2<0} {set ss2 "-"} {set ss2 " "}
	if {$num1+$num2<0} {set ss0 "-"} {set ss0 " "}


	lassign [split $num1 .] n1pi n1pf
	lassign [split $num2 .] n2pi n2pf
	if {[string length $n1pi]>[string length $n2pi]} {set cpi [string length $n1pi]} {set cpi [string length $n2pi]}
	if {[string length $n1pf]>[string length $n2pf]} {set cpf [string length $n1pf]} {set cpf [string length $n2pf]}
	
	incr cpi 2
	set s0 [format "%*s.%-*s" $cpi "" $cpf ""]
	set s1 [format "%*s.%-*s" $cpi $n1pi $cpf $n1pf]
	set s2 [format "%*s.%-*s" $cpi $n2pi $cpf $n2pf]
	set t1 [format "%*s.%-*s" $cpi "" $cpf ""]
	set out "[string trimright [string trimright $s1 " "] .]\n\037[string replace [string trimright $s2 .] 0 0 +]\037"

	set s0 [string map {" " 0} $s0]
	set s1 [string map {"-" 0 " " 0} $s1]
	set s2 [string map {"-" 0 " " 0} $s2]

	for {set i [expr [string length $s1]-1]} {$i>=0} {incr i -1} {
		if {[string index $s1 $i]=="."} {continue}

		set k [format %02d [string range [expr $ss0[string index $s0 $i]+$ss1[string index $s1 $i]+$ss2[string index $s2 $i]] end-1 end]]
#putnow "privmsg $canal :>$i< >$k<  >[expr $ss1[string index $s1 $i]+$ss2[string index $s2 $i]]<  >[string index $s0 $i]< >$ss1< >[string index $s1 $i]< >$ss2< >[string index $s2 $i]<"
		lassign [split $k {}] k1 k2
		set t1 [string replace $t1 $i $i $k2]
		set s0 [string replace $s0 [if {[string index $s0 $i-1]=="."} {set a [expr $i-2]} {set a [expr $i-1]}] [if {[string index $s0 $i-1]=="."} {set a [expr $i-2]} {set a [expr $i-1]}] $k1]
	}

	for {set k 0} {$k<[string first . $t1]-1} {incr k} {
		if {[regexp {[1-9]} [string index $t1 $k]]} {break}
		if {[string index $t1 $k]=="0"} {
			set t1 [string replace $t1 $k $k " "]
		}
	}

	putnow "privmsg $canal :[string map {1 ¹ - " " 0 " " . " "} $s0]\n$out\n[string replace [string trimright [string trimright $t1 " "]  .] 0 0 $ss0]    >[expr $num1+$num2]<"
	return [string trim $ss0[string trim [string trim [string trim $t1 0] .]]]
}

proc csub {canal num1 num2} {
#	putnow "privmsg $canal :codigo"
	expr {$num1-$num2}
}

proc tp:calc {quem canal text} {
	set text [string map {" " ""} $text]
	if {$text==""} {
		putnow "privmsg $canal :Expressão em falta."
		return
	}
	set text [string trim $text +]
	set text [string trim $text *]
	set text [string trim $text /]
	append text " "
	set elems [string map {, "." + " + " * " * " / " / " x " * " : " / "} $text]

	set elems [string map {". " " " " ." " 0."} $elems]

	set elems [string map {+- " - " -- " + "} $elems]

	regsub -all {([0-9])\-([0-9])} $elems {\1 - \2} elems
    regsub -all {([0-9])\-([0-9])} $elems {\1 - \2} elems

	set elems [string map {" + -" - "- + " " - " " *  + " " * " " /  + " " / " "  " " "} $elems]
	#if {[string first . $elems]>0} {set elems [string trimright [string trimright [string trimright $elems] 0] .]}

	set elems [string trim $elems]
    regsub -all {([0-9])\-([0-9])} $elems {\1 - \2} elems

	putnow "privmsg $canal :>>>$elems<<<"
	if {[catch {expr $elems} erro]} {
		putnow "privmsg $canal :ERRO: [tr $erro]"
		return
	}
	set pass 1
	while {$pass<100} {
		#if {![regexp {[+\-*/]} $elems]} {break}
		set elems [string map {" - -" " + "} $elems]
		for {set i 0} {$i<=[llength $elems]-2} {incr i 2} {
			lassign [lrange $elems $i $i+2] num1 operador num2
			if {[string first . $num1]>0} {set num1 [string trimright [string trimright $num1 0] .]}
			if {[string first . $num2]>0} {set num2 [string trimright [string trimright $num2 0] .]}

			if {$operador=="*" || $operador=="/"} {
				putnow "privmsg $canal := [lreplace $elems $i $i+2 \037$num1 $operador $num2\037]"
				if {$operador=="*"} {
					set elems [lreplace $elems $i $i+2 [cmul $canal $num1 $num2]]
					break
				}
				if {$operador=="/"} {
					set elems [lreplace $elems $i $i+2 [cdiv $canal $num1 $num2]]
					break
				}
			} elseif {($operador=="+" || $operador=="-") && ![regexp {[*/]} $elems]} {
				set eq1 [lreplace $elems $i $i+2 \037$num1 $operador $num2\037]
				lassign [expr {$num1 < 0 ? "$num2 - [expr {abs($num1)}]" : ($num2 > $num1 ? "$num2 + $num1" : "$num1 + $num2")}] tnum1 toperador tnum2
				set eq2 [lreplace $elems $i $i+2 \037$tnum1 $toperador $tnum2\037]

				putnow "privmsg $canal := $eq1 [if {$eq1!=$eq2} {lassign $eq2 $num1 $operador $num2; set a "= $eq2"}]"
				
				if {$operador=="+"} {
					set elems [lreplace $elems $i $i+2 [csum $canal $num1 $num2]]
					break
				}
				if {$operador=="-"} {
					set elems [lreplace $elems $i $i+2 [csub $canal $num1 $num2]]
					break
				}
			}
		}
		incr pass
	}
	putnow "privmsg $canal := $elems"
}

bind calc tp:calc
