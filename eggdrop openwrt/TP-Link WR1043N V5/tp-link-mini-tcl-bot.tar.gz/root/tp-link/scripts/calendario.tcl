proc tp:cal {quem chan text} {
	set mes [lindex $text 0]
	set ano [lindex $text 1]
	if {$mes==""} {set mes [strftime %N]}
	if {$ano==""} {
		set ano [strftime %Y]
	} else {
		if {![string is integer -strict $ano]} {
			putnow "PRIVMSG $chan :Ano inválido"
			return
		} else {
			if {$ano<1903 || $ano>2036} {
				putnow "PRIVMSG $chan :O ano não pode ser menos que 1903 ou maior que 2036"
				return
			}
		}
	}
	switch -nocase [string trim $mes] {
		jan - janeiro - 1	{set dias 31; set mes 1}
		fev - fevereiro - 2	{if {[expr $ano%4]==0} {set dias 29} {set dias 28}; set mes 2}
		mar - março - 3		{set dias 31; set mes 3}
		abr - abril - 4		{set dias 30; set mes 4}
		mai - maio - 5		{set dias 31; set mes 5}
		jun - junho - 6		{set dias 30; set mes 6}
		jul - julho - 7		{set dias 31; set mes 7}
		ago - agosto - 8	{set dias 31; set mes 8}
		set - setembro - 9	{set dias 30; set mes 9}
		out - outubro - 10	{set dias 31; set mes 10}
		nov - novembro - 11	{set dias 30; set mes 11}
		dez - dezembro - 12	{set dias 31; set mes 12}
		default	{
			putnow "PRIVMSG $chan :Mês inválido." 
			return
		}
	}
	set d0 ""; set d1 ""; set d2 ""; set d3 ""; set d4 ""; set d5 ""; set d6 ""
	set smes [lindex "- Janeiro Fevereiro Março Abril Maio Junho Julho Agosto Setembro Outubro Novembro Dezembro" $mes]

	set ctitulo "$smes $ano"
	set ptitulo [expr {round(24/2)-round([string length $ctitulo]/2)}]
	set ctitulo [string replace "                        " $ptitulo [expr $ptitulo+[string length $ctitulo]-1] $ctitulo]


	lappend c(1) "\0030,2$ctitulo\003"
	lappend c(2) "    \0034Do\003 2ª 3ª 4ª 5ª 6ª Sá"

	set ds [strftime %w [clock scan 1/$mes/$ano -format %d/%N/%Y]]
	set sa [scan [strftime %U [clock scan 1/$mes/$ano -format %d/%N/%Y]] %02d]

	#construir o calendário
	set jc 3

	mapadatas $ano
	for {set dia 1} {$dia<=$dias} {incr dia} {
		if {[lindex $::mcal($dia/$mes) 0]!="-"} {
			append fases "[lindex $::mcal($dia/$mes) 0]: $dia  "
		}
	}
	lappend eventos $fases ""

	for {set dia 1} {$dia<=$dias} {incr dia} {
		if {$dia==1} {
			set mespassado [expr $mes-1]
			if {$mespassado==0} {set mespassado 12}
			switch $mespassado {
				1 - 3 - 5 - 7 - 8 - 10 - 12	{set dmp 31}
				4 - 6 - 9 - 11 {set dmp 30}
				2 {if {[expr $ano%4]==0} {set dmp 29} {set dmp 28}}
			}
			for {set dst [expr $ds-1]} {$dst>=0} {incr dst -1} {
				set d$dst [format "\00314%*s\003" 2 $dmp]
				incr dmp -1
			}

		}

		set d$ds $dia

		#foreach linha [split $ddatas "\n"] {
		#	set edata [split $linha "|"]
		#	if {"$dia/$mes"=="[lindex $edata 0]/[lindex $edata 1]" && ($ano==[lindex $edata 2] || [lindex $edata 2]=="*")} {
		#		set d$ds [lindex $edata 3]
		#		lappend eventos "[if {[strftime %d/%m/%Y]=="[format "%02d" $dia]/[format "%02d" $mes]/$ano"} {set a "\002"}][lindex $edata 0] -> [lindex $edata 4]"
		#	}
		#}
		if {[lindex $::mcal($dia/$mes) 1]!=""} {
			set d$ds [lindex $::mcal($dia/$mes) 1]
			lappend eventos "$dia -> [lindex $::mcal($dia/$mes) 2]"
			#caso haja um evento no index 3 e 4
			if {[lindex $::mcal($dia/$mes) 3]!=""} {
				lappend eventos "$dia -> [lindex $::mcal($dia/$mes) 4]"
			}
		}

		if {[strftime %d/%m/%Y]=="[format %02d $dia]/[format "%02d" $mes]/$ano"} {
			set d$ds "[format "\026%*s\026" 2 [subst \$d$ds]]"
		}
		if {$dia==$dias || $ds==6} { 
			set ddepois 1
			for {set ds [expr $ds+1]} {$ds<=6} {incr ds} {
				set d$ds [format "\00314%*s\003" 2 $ddepois]
				incr ddepois
			}
			lappend c($jc) "[format "\%*s \0034 %*s\003 %*s %*s %*s %*s %*s %*s" 2 [format "%02d" $sa] 2 $d0 2 $d1 2 $d2 2 $d3 2 $d4 2 $d5 2 $d6]"
			incr jc
			incr sa
			set ds 0
			set d0 ""; set d1 ""; set d2 ""; set d3 ""; set d4 ""; set d5 ""; set d6 ""
			continue
		}
		incr ds
	}

	set jo 0
	foreach linha [lsort -integer [array names c]] {
		putnow "privmsg $chan :[lindex $c($linha) 0] | [lindex $eventos $jo]"
		incr jo
	}
	catch {unset ::mcal}
}

if {$texto=="!horas"} {
	putnow "PRIVMSG #konoha :São [strftime %H:%M:%S]"
}

proc putnowa {textoaenviar} {
	puts $::fd "PRIVMSG #konoha :$textoaenviar"
	flush $::fd
}

bind cal tp:cal
set dscript(calendario.tcl) "Calendário simples"
