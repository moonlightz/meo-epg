proc tp:sopa {quem canal text} {
# Word Search game in Tcl

# Read the word list from a file
set f [open "palavras.txt" r]
set words [split [read -nonewline $f] "\n"]
close $f

# Define the grid size and generate a grid of random letters
set gridsize 15
set letters {A B C D E F G H I J K L M N O P Q R S T U V W X Y Z}
set grid {}
for {set i 0} {$i < $gridsize} {incr i} {
    set row {}
    for {set j 0} {$j < $gridsize} {incr j} {
        lappend row [lindex $letters [expr {int(rand()*26)}]]
    }
    lappend grid $row
}

# Add the words to the grid
foreach word $words {
    set placed 0
    while {!$placed} {
        set dir [lindex {{1 0} {-1 0} {0 1} {0 -1} {1 1} {1 -1} {-1 1} {-1 -1}} [expr {int(rand()*8)}]]
        set startx [expr {int(rand()*($gridsize - [string length $word]))}]
        set starty [expr {int(rand()*($gridsize - [string length $word]))}]
        set endx [expr {$startx + [lindex $dir 0] * [string length $word]}] 
        set endy [expr {$starty + [lindex $dir 1] * [string length $word]}] 
        set placed 1
        for {set i $startx} {$i <= $endx} {incr i [lindex $dir 0]} {
            for {set j $starty} {$j <= $endy} {incr j [lindex $dir 1]} {
                if {[lindex $grid $i $j] ne "" && [lindex $grid $i $j] ne [string index $word [expr {($i - $startx) / ([lindex $dir 0] == 0 ? 1 : [lindex $dir 0])}]]} {
                    set placed 0
                }
            }
        }
        if {$placed} {
            for {set i $startx} {$i <= $endx} {incr i [lindex $dir 0]} {
                for {set j $starty} {$j <= $endy} {incr j [lindex $dir 1]} {
                    set char [string index $word [expr {($i - $startx) / ([lindex $dir 0] == 0 ? 1 : [lindex $dir 0])}]]
                    set row [lindex $grid $i]
                    set row [string replace $row $j $j $char]
                    set grid [lreplace $grid $i $i $row]
                }
            }
        }
    }
}	 


# Display the word grid

foreach row $grid {
    putnow "privmsg $canal :[join $row " "]"
}
return
# Start the game loop
set found {}
while {[llength $found] != [llength $words]} {
    # Get a guess from the player
    puts "Enter a word to find:"
    gets stdin guess

    # Check if the guess is correct
    if {$guess in $words && $guess ni $found} {
        puts "Congratulations, you found the word $guess!"
        lappend found $guess
    } else {
        puts "Sorry, $guess is not in the word list or you already found it. Try again."
    }
}
}

# End the game
puts "You found all the words! Game over."

bind sopa tp:sopa
set dscript(wordsearch.tcl) "sopa"

