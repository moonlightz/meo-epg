<?php

//System name
$sys_name['lang_name'] = 'Português (Portugal)';
$sys_name['lang_code'] = 'pt-pt';
$sys_name['lang_autor'] = '@moonlightz';

//Index page
$lang['description'] = 'Gerador de links online para o Microsoft Store. Pode utilizá-lo para obter links para quase todas as apps, jogos, temas do Microsoft Store.';
$lang['title_text'] = 'Gerador de links online para o Microsoft Store.<br>Insira o link do Microsoft Store e clique na caixa - para obter todos os links disponíveis.';
$lang['type'] = 'Seleccione o seu tipo de pedido';
$lang['url'] = 'Dados de Exemplo: ';
$lang['ring'] = 'Seleccione o canal';
$lang['sumbit'] = 'Gerar links temporários';

//GetFiles page
$lang['get_good'] = 'Os links foram recebidos com sucesso a partir do servidor do Microsoft Store.';
$lang['file'] = 'Ficheiro';
$lang['expire'] = 'Expira';
$lang['size'] = 'Tamanho';
$lang['stop_error'] = 'O servidor devolveu uma lista vazia.<br>Ou não inseriu o link correctamente, ou este serviço não suporta generação para este produto.';
$lang['stop_price'] = 'O servidor devolveu uma lista vazia.<br>Esta aplicação é paga e esta é uma completa violação dos direitos do Microsoft Store.';
