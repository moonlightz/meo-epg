opkg update
opkg install nano-plus wget-ssl coreutils-nohup tcl openssh-sftp-server
