proc putnow {textoaenviar} {
	global fd lcanais 
	if {[string toupper [string range $textoaenviar 0 8]]=="PRIVMSG #"} {
		set prmsg [string range $textoaenviar 0 [string first ":" $textoaenviar]]
		set strmt [list "\n" "\n$prmsg"]
		set ocanal [string range $textoaenviar 8 [string first " " $textoaenviar 8]-1]
		if {[lsearch -nocase $lcanais $ocanal]<0} {
			puts $fd "PRIVMSG #konoha :⚠️ \002$ocanal\002 não é um canal válido"
			flush $fd
			return
		}
		set textoaenviar [string map $strmt $textoaenviar]
		foreach linha [split $textoaenviar "\n"] {
			if {[string length $linha]>474} {
				set 1linha "sim"	
				for {set a 0} {$a<=[string length $linha]} {incr a+474} {
					if {$1linha=="sim"} {
						lappend sout [string range $linha 0 474]
						set 1linha "nao"
					} else {
						lappend sout "$prmsg[string range $linha $a 474-[string length $prmsg]]"
					}
				}
				continue
			}
			lappend sout $linha
		}
		set textoaenviar [join $sout "\n"]
	}

	set	icount 0
	foreach linha [split $textoaenviar "\n"] {
		incr icount
		if {$icount>5} {sleep 1000}
		puts $fd $linha
		flush $fd
	}
}
set dscript(putnow.tcl) "Mecanismo de envio"
