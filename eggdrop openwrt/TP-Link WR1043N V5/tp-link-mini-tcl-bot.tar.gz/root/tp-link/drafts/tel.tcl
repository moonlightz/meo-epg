#!/bin/tclsh

proc acceptConnection {server} {
  set sock [socket $server $port]
  fconfigure $sock -blocking 0 -buffering none
  fileevent $sock readable "handleInput $sock"
}

proc handleInput {sock} {
  while {[gets $sock line] != -1} {
    set command [string trim $line]
    if {$command == "time"} {
      puts $sock [clock format [clock seconds] -format "%H:%M:%S"]
    } else {
      puts $sock "Unknown command: $command"
    }
    puts $sock "Enter command: "
  }
  close $sock
}

proc main {} {
set hostname localhost
set port 23

  set server [socket -server acceptConnection $hostname $port]
  puts "Telnet server started on $hostname:$port"
  vwait forever
}

main
