proc multable {rows cols} {
set res ""; for {set i 1} {$i <= $rows} {incr i} {for {set j 1} {$j <= $cols} {incr j} {append res [format %4d [expr {$i*$j}]]}; append res \n}; set res
}
