proc wordSearch {grid words} {
	set gd [dict create]
	set rcnt 0
	set ccnt 0
	set row 0

	# create a matrix-like dict for convenience
	foreach l [split $grid \n] {
		set sl [string trim $l]
		if {$sl eq "" } {
			continue
		}
		set col 0 
		foreach c [split [string trim $l] ""] {
			dict set gd "$row,$col" $c 
			incr col
			if { $col > $ccnt } {
				set ccnt $col
			}
		}
		incr row

		if { $row > $rcnt } {
			set rcnt $row
		}
	}

	set found [dict create]

	foreach word $words {
		dict set found $word {}
	}



	# for every entry in the grid, search all directions

	for {set r 0} {$r < $row} {incr r} {
		for {set c 0} {$c < $col} {incr c} {
			foreach dir {n ne nw s se sw e w} { 
				set res [search $gd [list $r $c] [list $r $c] $dir [dict get $gd "$r,$c"] $words]
				if { $res ne "" } {
					lassign $res word sidx eidx
					dict set found $word [list [_rev_idx [_bump_idx $sidx]] [_rev_idx [_bump_idx $eidx]]]
				}
			}
		}
	}
	return $found
}



proc _bump_idx { idx } {
# indexes expected to start from 1,1
	return [list [expr {[lindex $idx 0] + 1}] [expr {[lindex $idx 1] + 1}]]
}



proc _rev_idx { idx } {
# row/col indexes seem transposed in the tests!
	return [list [lindex $idx 1] [lindex $idx 0]]
}



# 0, 0 will be the top left of the grid

proc search { grid sidx cidx dir curstr words} {
	# modify the current index
	switch -exact -- $dir {
		"ne"	{set delta {1 -1}}
		"n"		{set delta {0 -1}}
		"s"		{set delta {0 1}}
		"nw"	{set delta {-1 -1}}
		"e"		{set delta {1 0}}
		"w"		{set delta {-1 0}}
		"sw"	{set delta {-1 1}}
		"se"	{set delta {1 1}}
	}

	set cidx [list [expr {[lindex $delta 0] + [lindex $cidx 0]}] [expr {[lindex $delta 1] + [lindex $cidx 1]}]]

	set dkey [join $cidx ,]

	if { ![dict exists $grid $dkey] } {
		# off the grid

		return {}
	}

	set nc [dict get $grid $dkey]
	set nstr "${curstr}$nc"

	if { $nstr in $words } {
	# we have found a word
		return [list $nstr $sidx $cidx]
	}

	set matches [lmap word $words {if {[string match "${nstr}*" $word]} { set word} else continue}]
	if { [llength $matches] == 0 } {
		# no more words to find in this direction
		return {}
	}
	return [search $grid $sidx $cidx $dir "${curstr}$nc" $words]
}


