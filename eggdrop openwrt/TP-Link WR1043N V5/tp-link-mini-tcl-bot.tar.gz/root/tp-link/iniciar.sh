chmod +x tplinkbot.tcl
#(crontab -l 2>/dev/null; echo "* * * * * cd /root/tp-link && /root/tp-link/tplinkbot.tcl 2>&1") | crontab -
(echo "* * * * * cd /root/tp-link && /root/tp-link/tplinkbot.tcl 2>&1") | crontab -
