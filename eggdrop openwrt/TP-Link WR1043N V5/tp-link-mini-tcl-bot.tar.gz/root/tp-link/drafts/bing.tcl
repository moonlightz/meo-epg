proc tp:wolfram {quem canal text} {
	package require http
	package require json

# Set the API key
set api_key "your_api_key_here"

# Set the query
set query "search_query_here"

# Construct the URL for the API request
set url "http://api.wolframalpha.com/v2/query?input=$query&appid=$api_key"

# Send the API request
set response [http::geturl $url]

# Extract the response body
set result [http::data $response]

# Parse the XML response
set parser [xml::parser Create $result]
set tree [$parser parse]

# Extract the first 3 results
set count 0
set results {}
foreach pod $tree {
  if {[lindex $pod 0] == "pod" && [lindex $pod 1 "title"] == "Result"} {
    set result [lindex $pod 2 0 1]
    lappend results $result
    incr count
  }
  if {$count == 3} {
    break
  }
}

# Print the results
puts $result

}

bind wolfram tp:wolfram
set dscript(wolfram.tcl) "Wolfram Alpha"
