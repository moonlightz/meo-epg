#tcl foreach i {A 1 K c z 0 7} {  rswitch $i {         A..Z {putnow "privmsg #konoha :$i = MAIUSCULA"}         a..z {putnow "privmsg #konoha :$i = minuscula"}  0..9 {putnow "privmsg #konoha :$i = digito"} }}
proc rswitch {value body} {
	set go 0
	foreach {cond script} $body {
		if {[regexp {(.+)\.\.(.+)} $cond -> from to]} {
			if {$value >= $from && $value <= $to} {incr go}
		} else {
			if {$value == $cond} {incr go}
		}
		if {$go && $script ne "-"} { #(2)
			uplevel 1 $script
			break
		}
	}
	if {$cond eq "default" && !$go} {uplevel 1 $script}
}

proc formatarbytes {value} {
	set len [string length $value]
	if {$value < 1000} {
		return [format "%s B" $value]
	} else {
		set unit [expr {($len - 1) / 3}]
		return [format "%.1f %s" [expr {$value / pow(1000,$unit)}] [lindex [list B KB MB GB TB PB EB ZB YB] $unit]]
	}
}

proc ldadic {{list1 ""} {list2 ""}} {
	#mostra itens adicionados à lista2
    set adic ""
    foreach item $list2 {
        if {$item ni $list1} {lappend adic $item}
    }
    return $adic
}

proc ldremo {{list1 ""} {list2 ""}} {
	#mostra itens removidos da lista2
	set remo ""
	foreach item $list1 {
		if {$item ni $list2} {lappend remo $item}
	}
	return $remo
}

proc formatarbytes {value} {
	set len [string length $value]
	if {$value < 1000} {
		return [format "%s B" $value]
	} else {
		set unit [expr {($len - 1) / 3}]
		return [format "%.1f %s" [expr {$value / pow(1000,$unit)}] [lindex [list B KB MB GB TB PB EB ZB YB] $unit]]
	}
}


proc colunizar {entrada {ncolunas 8} {maxcaracteres 144}} {
	set nentrada [llength $entrada]
	set comp 0
	foreach i $entrada {
		if {[string length $i]>$comp} {set comp [string length $i]}
	}
	for {set numcolunas $ncolunas} {$numcolunas>1} {incr numcolunas -1} {
		if {[expr 22+$comp*$numcolunas+($numcolunas-1)*2]<=$maxcaracteres} {
			set ncolunas $numcolunas
			break
		}
	}
	foreach i [lsort -dictionary $entrada] {
		lappend lista [format "%-${comp}s" $i]
	}

	set i 1
	for {set cont 0} {$cont<$nentrada} {incr cont} {
		lappend out[format %03d $i] [lindex $lista $cont]
		incr i
		if {$i>[expr int(($nentrada-1)/$ncolunas)+1]} {
			set i 1
		}
	}

	set saida ""
	foreach var [lsort [lsearch -all -inline [info vars] out*]] {
		append saida "[string trimright [join [subst $$var] "  "]]\n"
	}
	return [string trimright $saida "\n"]
}

##
foreach {match p} [regexp -all -inline -- {bot:(.*?) } "[info procs] "] {
	rename bot:$p ""
}


proc bot:vars {canal lvars} {
	putnow "PRIVMSG $canal :[llength $lvars] variáveis:\n[colunizar [lsort -dictionary $lvars] 10]"
}

proc bot:clientes {canal} {
	set iw(out) [string map {"\n" "@"} [exec iwinfo phy0-ap0 assoclist]]
	set iw(lista) [regexp -all -inline -- {([0-9A-F:]{17})  (.*?) dBm / (.*?) dBm \(SNR (.*?)\)  (.*?) ms ago@\tRX: (.*?)  (.*?) Pkts.@\tTX: (.*?)  (.*?) Pkts.@\texpected throughput: (.*?) MBit/s} $iw(out)]

	putnow "PRIVMSG $canal :[format "%*s  %-*s  %*s  %*s  %*s  %*s  %-*s  %*s  %-*s  %*s  %*s" 2 ID 17 "Endereço MAC" 5 Sinal 5 Ruído 3 SNR 5 ms 28 RX 9 Pacotes 28 TX 9 Pacotes 5 Mbits]"

	set cor 14
	set contador 0
	foreach {- iw(mac) iw(dbmrx) iw(dbmtx) iw(snr) iw(ms) iw(rx) iw(rxpacotes) iw(tx) iw(txpacotes) iw(esperado)} $iw(lista) {
		incr contador
		putnow "PRIVMSG $canal :\0030,$cor[format "\00311\t%*s\0030  %*s  %*s  %*s  %*s  %*s  %-*s  %*s  %-*s  %*s  %*s" 2 $contador 17 $iw(mac) 5 $iw(dbmrx) 5 $iw(dbmtx) 3 $iw(snr) 5 $iw(ms) 28 $iw(rx) 9 [string trim $iw(rxpacotes)] 28 $iw(tx) 9 [string trim $iw(txpacotes)] 5 $iw(esperado)]"
		if {$cor==14} {set cor 2} {set cor 14}
	}
}

proc bot:info {canal} {
	putnow "PRIVMSG $canal :\002Processo:\002 [pid]  \002Tcl runtime:\002 [info patchlevel]  \002Tamanho de $::fichlog:\002 [file size $::fichlog] bytes"
}

proc bot:packages {quem canal texto} {
	catch {package require .}
	set largura 144
	#package require inifile
	#if {[file exists config/users.ini]} {
	#	set fi [ini::open config/users.ini]
	#	set largura [ini::value $fi $quem Largura]
	#	ini::close $fi
	#}
	if {[string trim $texto]==""} {
		set lista [package names]
	} else {
		 set lista [lsearch -all -inline [package names] $texto]
	}
	set pacotes ""
	putnow "PRIVMSG $canal :[llength $lista] pacote[if {[llength $lista]>1} {set q "s"}]:\n[colunizar [foreach p $lista {lappend pacotes "$p [if {[package versions $p]!=""} {set a [package versions $p]} {set a "N/A"}]"}; set pacotes] 8 $largura]"
}

proc bot:backup {canal} {
	set t1 [clock milliseconds]
	set nomefich tl-[strftime %Y%m%d-%H%M%S].tar.gz
	if {!$::executado} {
		putnow "PRIVMSG $canal :A criar backup manual para $nomefich, aguarde ..."
	}
	exec tar zcf /tmp/$nomefich -C /root tp-link
	set lista [exec tar -ztvf /tmp/$nomefich]
	set total 0; set dirs 0; set fichs 0
	foreach linha [split  $lista "\n"] {
		if {[string index $linha 0]=="d"} {incr dirs} {incr fichs}
		incr total [lindex $linha 2]
	}
	exec scp /tmp/$nomefich z83ii@192.168.1.250:/media/z83ii/sandisk/bktplinkbot
	if {!$::executado} {
		set ftotal [file size /tmp/$nomefich]
		putnow "PRIVMSG $canal :$dirs directórios e $fichs ficheiros comprimidos.\nTotal de $total bytes comprimidos em $ftotal bytes (rácio de compressão: [format "%.02f" [expr 100.00*$ftotal/$total]]%).\nFicheiro de backup enviado. Operação efectuada em [string map {"." ","} [expr ([clock milliseconds]-$t1)/1000.000]] segundos!"
	}
	file delete "/tmp/$nomefich"
}

proc bot:ajuda {canal} {
 	foreach {match p} [regexp -all -inline -- {bot:(.*?) } "[info procs] "] {lappend lcomandos $p}
	putnow "PRIVMSG $canal :Comandos $::botnick <opção>: \002[lsort $lcomandos]\002"
	foreach {match p} [regexp -all -inline -- {tp:(.*?) } "[info procs] "] {lappend loutros $p}
	putnow "PRIVMSG $canal :Outros: \002[lsort $loutros]\002"
}

proc bot:restart {} {
	#este proc foi deixado vazio
}

proc bot:die {canal} {
	if {[users "$::quem!$::uhost"]} {
		set msgs {"Oh não!! Estou a derreter... estou a derreter...." "Hasta la vista, baby!" "Mayday, mayday. This is the Trawler Annabelle. I've lost my bearings, and I'm taking on water." "Houston, we have a problem..." 
			"Smith is suffice." "Not like this. Not like this..."}
		putnow "QUIT :[lindex $msgs [expr int(rand()*[llength $msgs])]]"
		exit
	} else {
		putnow "PRIVMSG $canal :Quem és tu?"
	}
}

proc bot:scripts {canal} {
	set tamcoluna1 6

	foreach i $::botscripts {
		if {[string length $i]>$tamcoluna1} {set tamcoluna1 [string length $i]}
	}

	putnow "privmsg $canal :[format "%-*s   %-*s  %*s  %-*s  %-*s" $tamcoluna1 "Script" 21 "Data da modificação" 7 "Tamanho" 3 "Atr" 9 "Descrição"]"
	set atr {"---" "--x" "-w-" "-wx" "r--" "r-x" "rw-" "rwx"}
	foreach i $::botscripts {
		set mdata [string map {
			Feb Fev Abr Apr May Mai Aug Ago Sep Set Oct Out Dec Dez Mon Seg Tue Ter Wed Qua Thu Qui Fri Sex Sat Sáb Sun Dom
			} [strftime "%a %d/%b/%Y %H:%M" [file mtime scripts/$i]]]
		putnow "privmsg $canal :[format "%*s%-*s  %-*s  %*s  %*s  %-*s" 1 "📃" $tamcoluna1 $i 21 $mdata 7 [file size scripts/$i] \
			3 [lindex $atr [string index [file attributes "scripts/$i" -permissions] 2]] \
			50 [if {[lsearch [array names ::dscript] $i]>=0} {set a $::dscript($i)} {set a "N/A"}]]"
	}
}

proc bot:portas {canal} {
	set iw(out) [string map {"\t" ""} [exec swconfig dev switch0 show]]
	set iw(out) [string range $iw(out) [string first "igmp_v3" $iw(out)] end]

	set vazio "N/A"
	#set vazio "-"
	set tabela(cab)		"{%-*s %-*s %-*s %-*s %-*s %-*s} Porta Estado Velocidade Duplex {RX bytes} {TX bytes}"
	set tabela(cpu)		"{%-*s %-*s %-*s %-*s %*s %*s} CPU $vazio $vazio $vazio $vazio $vazio"
	set tabela(lan1)	"{%-*s %-*s %-*s %-*s %*s %*s} {LAN 1} $vazio $vazio $vazio $vazio $vazio"
	set tabela(lan2)	"{%-*s %-*s %-*s %-*s %*s %*s} {LAN 2} $vazio $vazio $vazio $vazio $vazio"
	set tabela(lan3)	"{%-*s %-*s %-*s %-*s %*s %*s} {LAN 3} $vazio $vazio $vazio $vazio $vazio"
	set tabela(lan4)	"{%-*s %-*s %-*s %-*s %*s %*s} {LAN 4} $vazio $vazio $vazio $vazio $vazio"
	set tabela(wan)		"{%-*s %-*s %-*s %-*s %*s %*s} WAN $vazio $vazio $vazio $vazio $vazio"

	foreach item [string trim [split $iw(out) "\n"]] {
		if {[regexp {Port (.*?)\:} $item match porta]} {
			switch $porta {
				0 {set porta "cpu"}
				1 {set porta "lan4"}
				2 {set porta "lan3"}
				3 {set porta "lan2"}
				4 {set porta "lan1"}
				5 {set porta "wan"}
				default {break}
			}
		}

		if {[string range $item 0 12]=="RxGoodByte  :"} {set tabela($porta) [lreplace $tabela($porta) 5 5 [string trim [string range $item 14 end]]]}
		if {[string range $item 0 12]=="TxByte      :"} {set tabela($porta) [lreplace $tabela($porta) 6 6 [string trim [string range $item 14 end]]]}
		if {[string range $item 0 4]=="link:"} {
			set item [split $item " "]
			if {[lindex $item 2]=="link:up"} {set tabela($porta) [lreplace $tabela($porta) 2 2 "Ligado"]} {set tabela($porta) [lreplace $tabela($porta) 2 2 "Deslig"]}
			if {[string range [lindex $item 3] 0 5]=="speed:"} {set tabela($porta) [lreplace $tabela($porta) 3 3 [string range [lindex $item 3] 6 end]]}
			if {[string range [lindex $item 4] end-6 end]=="-duplex"} {set tabela($porta) [lreplace $tabela($porta) 4 4 [string totitle [string range [lindex $item 4] 0 3]]]}
		}
	}

	foreach item "cab cpu lan1 lan2 lan3 lan4 wan" {
		set item $tabela($item)
		putnow "privmsg $canal :[format [lindex $item 0] 6 [lindex $item 1] 7 [lindex $item 2] 11 [lindex $item 3] 7 [lindex $item 4] 27 [lindex $item 5] 27 [lindex $item 6]]"
	}
  
}

proc bot:tarefas {canal} {
	if {![file exists "/root/tp-link/scripts/tarefas.tcl"]} {
		putnow "PRIVMSG $canal :O ficheiro tarefas.tcl não existe"
		return
	}
	set ftarefas [open scripts/tarefas.tcl r]
	set dtarefas [read $ftarefas]
	close $ftarefas

	set entradas [regexp -all -inline {\t\"(.*?)\" \{\n\t\#(.*?)\n} $dtarefas]
	set entradas2 ""
	foreach {match horario desc} $entradas {
		set horario [string map {"\" - \"" "/"} $horario]
		set horario2 ""
		foreach horaout [lsort [split $horario "/"]] {
			append horario2 "$horaout/"
		}
		set horario [string trimright $horario2 "/"]
		lappend entradas2 "$horario|$desc"
	}
	set entradas [lsort $entradas2]
	putnow "PRIVMSG $canal :Agora é: [strftime "%A %d/%B/%Y %H:%M"]"
	set agora [clock seconds]
	foreach i $entradas {
		set horario [lindex [split $i "|"] 0]
		set desc [lindex [split $i "|"] 1]
		set horaout ""
		foreach tempo [split $horario "/"] {
			set t1 [clock scan [string map {"\?" " " "\*" " " ": " ":00" " :" "00:" ":6" ":06" ":7" ":07" ":8" ":08" ":9" ":09" " " ""} $tempo]]
			append horaout "[if {$t1<$agora} {set symb "☑"} {set symb "⏲️"}] $tempo  "
		}
		putnow "PRIVMSG $canal :$horaout"
		putnow "PRIVMSG $canal :➤➤➤ $desc"
		#break
	}
}

proc bot:sysinfo {canal} {
	global openwrtversao
	#hostname mais kernel
	set sinfo(uname) [exec uname -snrm]
	set sinfo(msg) "\002Nome:\002 [lindex $sinfo(uname) 1]  \002SO:\002 [lindex $sinfo(uname) 0] [lindex $sinfo(uname) 2]/[lindex $sinfo(uname) 3]  "
	#distribuicao
	append sinfo(msg) "\002Distro:\002 $openwrtversao  "
	#soc, cpu
	set fcpu [open "/proc/cpuinfo" r]
	set sinfo(systemtype) [string range [gets $fcpu] 15 end]
	set sinfo(modelorouter) [string range [gets $fcpu] 12 end]
	gets $fcpu sinfo(cpu)
	set sinfo(cpu) [string range [gets $fcpu] 13 end]
	close $fcpu
	append sinfo(msg) "\002SoC:\002 $sinfo(systemtype)  \002Arq.:\002 $sinfo(cpu)  "
	#numero de processos
	append sinfo(msg) "\002Processos:\002 [exec ps | wc -l]  "
	#uptime
	set fuptime [open "/proc/uptime" r]
	gets $fuptime sinfo(ttempo)
	close $fuptime
	set sinfo(ttempo) [lindex [split $sinfo(ttempo) "."] 0]

	set zd [expr $sinfo(ttempo)/86400]
	set sinfo(ttempo) [expr $sinfo(ttempo)-$zd*86400]
	set zh [expr $sinfo(ttempo)/3600]
	set sinfo(ttempo) [expr $sinfo(ttempo)-$zh*3600]
	set zm [expr $sinfo(ttempo)/60]
	set sinfo(ttempo) [expr $sinfo(ttempo)-$zm*60]
	set zs $sinfo(ttempo)
	set sinfo(ttempo) ""
	if {$zd == 1} {append sinfo(ttempo) $zd "d "}
	if {$zd > 1} {append sinfo(ttempo) $zd "d "}
	if {$zh == 1} {append sinfo(ttempo) $zh "h "}
	if {$zh > 1} {append sinfo(ttempo) $zh "h "}
	if {$zm == 1} {append sinfo(ttempo) $zm "m "}
	if {$zm > 1} {append sinfo(ttempo) $zm "m "}
	if {$zs == 1} {append sinfo(ttempo) $zs "s "}
	if {$zs > 1} {append sinfo(ttempo) $zs "s "}
	if {$sinfo(ttempo) == ""} {set sinfo(ttempo) "0s"}
	set sinfo(ttempo) [string trimright $sinfo(ttempo)]
	append sinfo(msg) "\002Activo:\002 $sinfo(ttempo)  "

	set sinfo(tcarga) [exec uptime]
	append sinfo(msg) "\002Carga Media:\002 [string range [lindex $sinfo(tcarga) [llength $sinfo(tcarga)]-2] 0 end-1]  "

	set fmeminfo [open "/proc/meminfo"]
	gets $fmeminfo sinfo(ttotal)
	gets $fmeminfo sinfo(tfreemem)
	gets $fmeminfo sinfo(memavail)
	gets $fmeminfo sinfo(tbuffers)
	gets $fmeminfo sinfo(tcached)
	close $fmeminfo

	set sinfo(ttotal) [lindex $sinfo(ttotal) 1]
	set sinfo(tfreemem) [lindex $sinfo(tfreemem) 1]
	set sinfo(tbuffers) [lindex $sinfo(tbuffers) 1]
	set sinfo(tcached) [lindex $sinfo(tcached) 1]

	set sinfo(ttotal) [format "%.2f" [expr double($sinfo(ttotal))/1024]]
	set sinfo(tfreemem) [format "%.2f" [expr double($sinfo(tfreemem))/1024]]
	set sinfo(tbuffers) [format "%.2f" [expr double($sinfo(tbuffers))/1024]]
	set sinfo(tcached) [format "%.2f" [expr double($sinfo(tcached))/1024]]
	set sinfo(tfreemem) [format "%.2f" [expr $sinfo(ttotal)-$sinfo(tfreemem)-$sinfo(tbuffers)-$sinfo(tcached)]]

	set sinfo(tmemoria) "[string range $sinfo(tfreemem) 0 end]MB/[string range $sinfo(ttotal) 0 end]MB ([format "%.2f" [expr double($sinfo(tfreemem))/$sinfo(ttotal)*100]]%)"
	append sinfo(msg) "\002Memoria:\002 $sinfo(tmemoria)  "

	set sinfo(tdf) [exec df /]
	set sinfo(tdfusado) [lindex $sinfo(tdf) 9]
	set sinfo(tdftotal) [lindex $sinfo(tdf) 8]
	set sinfo(tdfpuso) [format "%.2f" [expr double($sinfo(tdfusado))/$sinfo(tdftotal)*100]]
	append sinfo(tdfusado) "KB"
	append sinfo(tdftotal) "KB"
	append sinfo(msg) "\002Uso disco:\002 $sinfo(tdfusado)/$sinfo(tdftotal) ($sinfo(tdfpuso)%)  "
	#wlan0
	set sinfo(wifi) [exec iwinfo phy0-ap0 info]
	regexp {ESSID: "(.*?)"} $sinfo(wifi) match sinfo(essid)
	regexp {Channel: (.*?)\n} $sinfo(wifi) match sinfo(canal)
	regexp {Bit Rate: (.*?)\n} $sinfo(wifi) match sinfo(bitrate)
	regexp {Encryption: (.*?)\n} $sinfo(wifi) match sinfo(encryption)
	append sinfo(msg) "\002WiFi:\002 Nome=$sinfo(essid) Canal=$sinfo(canal) Vel=$sinfo(bitrate) Enc=$sinfo(encryption) "
	set sinfo(wifi) [exec iwinfo [lindex $sinfo(wifi) 0] assoclist]
	append sinfo(msg) "Clientes=[expr [llength [regexp -all -inline {([0-9A-F:]{17})} $sinfo(wifi)]]/2]  "

	#modelo
	append sinfo(msg) "\002Router:\002 $sinfo(modelorouter)"
	#saida da mensagem
	putnow "PRIVMSG $canal :$sinfo(msg)"
}

proc bot:save {canal text} {
	if {$text==""} {
		putnow "PRIVMSG $canal :Guarda um procedimento presente na memória para ficheiro. Tem de especificar pelo menos 1 procedimento. [llength [info procs]] procedimentos em memória:"
		putnow "PRIVMSG $canal :[colunizar [info procs] 8]"
		return
	}
	foreach i $text {
		if {[lsearch -exact [info procs] $i]==-1} {
			putnow "PRIVMSG $canal :O procedimento $i não existe."
			return
		} else {
			set fich [open drafts/$i.tcl w+]
			puts $fich "proc $i \{[info args $i]\} \{"
			puts $fich "[info body $i]"
			puts $fich "\}"
			close $fich
			putnow "PRIVMSG $canal :$i.tcl guardado. [file size drafts/$i.tcl] bytes."
		}
	}
	
}

proc bot:scan {canal text} {
	if {[regexp -- { --help } " $text "]} {
		putnow "PRIVMSG $canal :-n x     Limita o número de entradas a mostrar\n--incr   Mostra as redes mais fracas primeiro\n--help   Mostra este texto de ajuda"
		return
	}

	regexp -- { -n (.*?) } " $text " match num
	if {[info exists num]} {
		if {![string is integer -strict $num]} {
			putnow "privmsg $canal :'$num' não é um número inteiro."
			return
		}
	} else {
		set num 5
	}
	if {$num<1} {
		putnow "PRIVMSG $canal :O número de redes a mostrar não pode ser menor que 1."
		return
	}

	set iw(out) [string map {"   " "" "\n" "" "none" "Nenhuma (Aberto)"} [exec iwinfo phy0-ap0 scan]]
	set iw(lista) [regexp -all -inline -- {Cell (.*?) - Address: (.*?) ESSID: "(.*?)" Mode: (.*?) .* Channel: (.*?) Signal: (.*?) dBm  Quality: (.*?)/70 Encryption: (.*?) HT} $iw(out)]


	set listawifi ""
	foreach {- iw(cell) iw(mac) iw(nome) iw(modo) iw(canal) iw(sinal) iw(qualidade) iw(enc)} $iw(lista) {
		lappend listawifi [list $iw(sinal) $iw(mac) $iw(nome) $iw(modo) $iw(canal) $iw(qualidade) $iw(enc)]
	}

	if {[regexp -- { --incr } " $text "]} {
		set listawifi [lsort -decreasing $listawifi]
	} else {
		set listawifi [lsort $listawifi]
	}
	putnow "PRIVMSG $canal :Número de redes detectadas: [llength $listawifi] | Signal Level mínimo de [lindex [lindex $listawifi end] 0] e máximo de [lindex [lindex $listawifi 0] 0]"
	
	set idx 0
	set cnomerede 18
	foreach item $listawifi {
		if {[string length [lindex $item 2]]>$cnomerede} {
			set cnomerede [string length [lindex $item 2]]
		}
		incr idx
		if {$idx>=$num} {break}
	}
	set idx 0
	putnow "PRIVMSG $canal :Força  dBm  Endereço MAC       Nome da rede Wi-Fi [string repeat " " [expr $cnomerede-18]] Modo    Ch  LQ  Segurança"
	set cor 5

	foreach iw(tmp) $listawifi {

		set ns [expr -1*[lindex $iw(tmp) 0]]
		if {$ns>=0 && $ns<=57}	{set sbar "\0039,93 \u2583\u2585\u2587\u2589"}
		if {$ns>=58 && $ns<=76} {set sbar "\0039,93 \u2583\u2585\u2587\0030\u2589"}
		if {$ns>=77 && $ns<=87} {set sbar "\0039,93 \u2583\u2585\0030\u2587\u2589"}
		if {$ns>=87 && $ns<=94} {set sbar "\0039,93 \u2583\0030\u2585\u2587\u2589"}
		if {$ns>=95 && $ns<=96} {set sbar "\00396,93 \u2583\u2585\u2587\u2589"}
		
		putnow "privmsg $canal :$sbar [format "\0030,$cor [lindex $iw(tmp) 0]  %*s  %-*s  %*s  %*s  %*s  %-*s\t" \
			17 [lindex $iw(tmp) 1] $cnomerede [lindex $iw(tmp) 2] 6 [lindex $iw(tmp) 3] 2 [lindex $iw(tmp) 4] \
			2 [lindex $iw(tmp) 5] 32 [lindex $iw(tmp) 6]] \n"
		incr idx
		if {$idx>=$num} {break}
		if {$cor==5} {set cor 2} {set cor 5}
	}
}

if {[lindex [split $texto] 0]==$botnick} {
	set arg1 [lindex [split $texto] 1]
	switch $arg1 {
		"vars"	{bot:vars $canal [info vars]}
		"info" - "clientes" - "portas" - "tarefas" - "scripts" - "backup" - "die" -  "sysinfo"
			{bot:$arg1 $canal}
		"packages" {
			bot:packages $quem $canal [lindex [split $texto] 2]
		}
		"scan" {
			bot:scan $canal [lrange [split $texto] 2 end]
		}
		"save" {
			bot:save $canal [lrange [split $texto] 2 end]
		}
		"restart"	{
			set nid 0
			putnow "QUIT :Volto já ..."
			close $fd
			set fd [socket $dstaddr $dstport]
			putnow "NICK $botnick"
			putnow "USER $botident \"\" \"\" :$gecos"
			bot:restart
		}
		default {bot:ajuda $canal}
	}
}


proc onchan {nick chan} {
	global fd
	if {[string trim $chan]=="" || [string trim $nick]==""} {return "-1"}
	putnow "WHO $chan"
	sleep 100
	set code ""
	while {$code!=315} { 
		set msg [gets $fd]
		set code [lindex $msg 1]
		if {[string tolower [lindex $msg 7]]==[string tolower $nick]} {
			return "1"
		}
	}
	return "0"
}

################
# CTCPs comuns #
################
if {[string range $texto 0 4]=="\001PING"} {
	putnow "NOTICE [lindex [split $quem "!"] 0] :\001PING [clock seconds]\001"
}

if {$texto=="\001VERSION\001"} {
	putnow "NOTICE [lindex [split $quem "!"] 0] :\001VERSION Tcl Runtime [info patchlevel]\001"
}

if {$texto=="\001TIME\001"} {
	putnow "NOTICE [lindex [split $quem "!"] 0] :\001TIME [strftime %c]\001"
}

if {$texto=="\001FINGER\001"} {
	putnow "NOTICE [lindex [split $quem "!"] 0] :\001FINGER $gecos\001"
}

if {$way=="KICK"} {
	set canal [lindex $canal 0]
	puts stdout "[logtime] Fui kickado por $quem. A voltar a entrar no canal $canal ..."
	sleep 2000
	putnow "JOIN $canal"
}

set dscript(core.tcl) "Funcionalidades do bot"
