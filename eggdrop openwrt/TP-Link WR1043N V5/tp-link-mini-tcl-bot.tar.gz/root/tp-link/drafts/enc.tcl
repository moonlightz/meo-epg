proc enc {toriginal lcaract} {
foreach palavra $toriginal {set comp [string length $palavra]; set pos [expr {1+int(rand() * ($comp-1))}]; append resultado [string range $palavra 0 [expr {$pos-1}]][lindex $lcaract [expr int(rand()*[llength $lcaract])]][string range $palavra $pos $comp]}; set resultado
}
