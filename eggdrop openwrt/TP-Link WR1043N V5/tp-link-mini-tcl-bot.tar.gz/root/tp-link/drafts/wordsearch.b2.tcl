proc shuffle_list {lst} {
  set n [llength $lst]
  for {set i 0} {$i < $n} {incr i} {
    set j [expr {int(rand() * $n)}]
    set tmp [lindex $lst $i]
    lset lst $i [lindex $lst $j]
    lset lst $j $tmp
  }
  return $lst
}

proc tp:sopa {quem canal text} {
# Define the grid size and word list
set x 10
set y 10
set word_list {
  APPLE
  BANANA
  CHERRY
  DATE
  EGGPLANT
  FIG
  GRAPE
  HONEYDEW
  INDIGO
  JACKFRUIT
}

# Generate the grid with random letters
set grid {}
for {set i 0} {$i < $x} {incr i} {
  for {set j 0} {$j < $y} {incr j} {
    set grid($i,$j) [expr {char(int(rand() * 26) + 65)}]
  }
}

# Generate a list of possible word positions
set word_positions {}
foreach word $word_list {
  set len [string length $word]
  set pos_dirs {}
  for {set dir 0} {$dir < 8} {incr dir} {
    set dx [expr {int(cos($dir * 3.14159 / 4))}]
    set dy [expr {int(sin($dir * 3.14159 / 4))}]
    lappend pos_dirs [list $dx $dy]
  }
  for {set i 0} {$i <= $x - $len} {incr i} {
    for {set j 0} {$j <= $y - $len} {incr j} {
      lappend word_positions [list $word $len $pos_dirs $i $j]
    }
  }
}

# Shuffle the list of word positions
set shuffled_positions [shuffle_list $word_positions]

# Place the words on the grid
foreach {word len pos_dirs x0 y0} $shuffled_positions {
  set found 0
  foreach {dx dy} $pos_dirs {
    set x1 [expr {$x0 + ($len - 1) * $dx}]
    set y1 [expr {$y0 + ($len - 1) * $dy}]
    if {$x1 < 0 || $x1 >= $x || $y1 < 0 || $y1 >= $y} {
      continue
    }
    set valid 1
    for {set i 0} {$i < $len} {incr i} {
      set c [string index $word $i]
      set x [expr {$x0 + $i * $dx}]
      set y [expr {$y0 + $i * $dy}]
      if {$grid($x,$y) ne "" && $grid($x,$y) ne $c} {
        set valid 0
        break
      }
    }
    if {$valid} {
      for {set i 0} {$i < $len} {incr i} {
        set c [string index $word $i]
        set x [expr {$x0 + $i * $dx}]
        set y [expr {$y0 + $i * $dy}]
        set grid($x,$y) $c
      }
      set found 1
      break
    }
  }
  if {!$found} {
    putnow "privmsg $canal: Could not find position for word $word"
  }
}

# Display the word grid

foreach row $grid {
    putnow "privmsg $canal :[join $row " "]"
}
return
# Start the game loop
set found {}
while {[llength $found] != [llength $words]} {
    # Get a guess from the player
    puts "Enter a word to find:"
    gets stdin guess

    # Check if the guess is correct
    if {$guess in $words && $guess ni $found} {
        puts "Congratulations, you found the word $guess!"
        lappend found $guess
    } else {
        puts "Sorry, $guess is not in the word list or you already found it. Try again."
    }
}
}

# End the game
puts "You found all the words! Game over."

bind sopa tp:sopa
set dscript(wordsearch.tcl) "sopa"

