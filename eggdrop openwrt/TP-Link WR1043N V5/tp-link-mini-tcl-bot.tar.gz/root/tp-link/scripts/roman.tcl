proc tp:roman {quem canal text} {
	set i [lindex [split $text] 0]
	if {$i==""} {
		putnow "privmsg $canal :Introduza um número inteiro. Ex: roman 1888"
	}
	if {![string is integer -strict $i]} {
		putnow "privmsg $canal :Tem de ser um número inteiro."
	}
	set res ""
	set rl {50000 \037L\037 49000 \037XL\037 10000 \037X\037 9000 M\037X\037 5000 \037V\037 4000 M\037V\037
		 1000 M 900 CM 500 D 400 CD 100 C 90 XC 50 L 40 XL 10 X 9 IX 5 V 4 IV 1 I}
	foreach {value roman} $rl {
		while {$i>=$value} {
			append res $roman
			incr i -$value
		}
	}
	putnow "PRIVMSG $canal :$res"
}

bind roman tp:roman
set dscript(roman.tcl) "Converte números para numeração romana"
