proc hexdump string {
	binary scan $string H* hex
	regexp -all -inline .. $hex
}

proc tp:hexdump {quem canal fich} {
	set fp [open $fich]
	fconfigure $fp -translation binary
	set n 0
	while {![eof $fp]} {
		set bytes [read $fp 16]
		regsub -all {[^\x20-\xfe]} $bytes . ascii
		append buf "[format "%08X  %-48s %-16s" $n [hexdump $bytes] "|$ascii|"]\n"
		incr n 16
	}
	close $fp
	putnow "PRIVMSG $canal :$buf"
}

bind hexdump tp:hexdump
set dscript(hexdump.tcl) "Representação hexadecimal de ficheiros"
