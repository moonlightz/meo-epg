proc opkgupdate {chan} {
	global openwrtnversao
	#BETA
#primeira vaga = ok
#adiante não
#encontrar alternativa de saber o tamanho e data
#Downloading https://downloads.openwrt.org/releases/23.05.0-rc3/packages/mips_24kc/base/ucode_2023-06-06-c7d84aae-1_mips_24kc.ipk
#	foreach tipo {base luci packages routing telephony}	{
#		set elem [regexp -all -inline {<tr><td class="n"><a href="(.*?)">(.*?)</a></td><td class="s">(.*?)</td><td class="d">(.*?)</td></tr>} [exec wget -q -O - https://downloads.openwrt.org/releases/$openwrtnversao/packages/mips_24kc/base/]]
#		foreach {match link nome tamanho data} $elem {
#			switch -glob -- $nome {
#				"*_mips_24kc.ipk" - "_all.ipk" {
#					lappend listpkgs([lindex [split $nome "_"] 0]) $tamanho $data"
#				}
#				default {continue}
#			}
#		}
#    putnow "privmsg $chan :[llength [array names listpkgs]]"
#		#putnow "privmsg $chan :>[lrange $elem 0 10]<"		
#		#criar um array
#	}



	set lelemopenwrt [regexp -all -inline {<tr><td class=\"n\"><a href=\"(.*?)\">(.*?)</a>/</td><td class=\"s\">-</td><td class=\"d\">(.*?)</td></tr>} [exec wget -q -O - https://downloads.openwrt.org/releases/]]
	foreach {m1 m2 versao data} $lelemopenwrt {
		if {![string match "fail*" $versao] && ![string match "pack*" $versao]} {
			lappend lversoes $versao
		}
	}
	for {set i 0} {$i<[llength $lversoes]} {incr i} {
		if {[string match "*.0" [lindex $lversoes $i]] && [string match "*.0-rc*" [lindex $lversoes $i+1]]} {
			set a [lindex $lversoes $i]
			set lversoes [lreplace $lversoes $i $i [lindex $lversoes $i+1]]
			set lversoes [lreplace $lversoes $i+1 $i+1 $a]
		}
	}
#Downloading https://downloads.openwrt.org/releases/23.05.0-rc3/packages/mips_24kc/base/ucode_2023-06-06-c7d84aae-1_mips_24kc.ipk
	set novaversao [lindex $lversoes end]
	if {$novaversao!=$openwrtnversao} {
		putnow "privmsg $chan :Existe uma nova versão de firmware! Versão actual: \002$openwrtnversao\002  Versão disponível: \002$novaversao\002"
		putnow "notice kashinkoji :https://downloads.openwrt.org/releases/$novaversao/targets/ath79/generic/openwrt-$novaversao-ath79-generic-tplink_tl-wr1043n-v5-squashfs-sysupgrade.bin"
	}

	putnow "PRIVMSG $chan :A descarregar a lista ..."
	set opkg [exec opkg update]
	putnow "PRIVMSG $chan :A ler a lista de actualizações ..."
	set opkg [exec opkg list-upgradable]
	set pnome 0; set pold 0; set pnovo 0
	foreach opkgi [split $opkg "\n"] {
		regexp -all -indices -- {(.*?) - (.*?) - (.*?)$} $opkgi -> inome iold inovo
		if {[expr [lindex $inome 1]-[lindex $inome 0]+1]>$pnome} {set pnome [expr [lindex $inome 1]-[lindex $inome 0]+1]}
		if {[expr [lindex $iold 1]-[lindex $iold 0]+1]>$pold} {set pold [expr [lindex $iold 1]-[lindex $iold 0]+1]}
		if {[expr [lindex $inovo 1]-[lindex $inovo 0]+1]>$pnovo} {set pnovo [expr [lindex $inovo 1]-[lindex $inovo 0]+1]}
	}
	set out ""
	foreach opkgi [split $opkg "\n"] {
		regexp -all -- {(.*?) - (.*?) - (.*?)$} $opkgi -> snome sold snovo
		append out "[format "%-*s  %-*s >> %-*s" $pnome $snome $pold $sold $pnovo $snovo]\n"

	}
	putnow "PRIVMSG $chan :$out"
	putnow "PRIVMSG $chan :[switch [llength [split $opkg "\n"]] {0 {set a "Não há actualizações disponíveis."} 1 {set a "1 actualização disponível."} default {set a "[llength [split $opkg "\n"]] actualizações disponiveis."}}]"
}

proc opkgupgrade {chan} {
	putnow "PRIVMSG $chan :A verificar quantos pacotes temos para actualizar ..."
	set opkg [exec opkg list-upgradable]
	set lista ""
	foreach pacote [split $opkg "\n"] {
		lappend lista [lindex $pacote 0]
	}
	if {[llength $lista]==0} {
		putnow "PRIVMSG $chan :Não há pacotes para actualizar."
		return
	}
	putnow "PRIVMSG $chan :[llength $lista] pacote[if {[llength $lista]>1} {set a "(s)"}]: $lista" 
	foreach pacote $lista {
		if {[catch {exec opkg upgrade $pacote} opkgi]} {
			putnow "PRIVMSG $chan :[tr $opkgi]"
			continue
		}
		putnow "PRIVMSG $chan :[tr $opkgi]"
	}
	putnow "PRIVMSG $chan :Feito."
}

proc opkgsearch {chan text} {
	if {$text==""} {
		putnow "PRIVMSG $chan :Utilização: opkg search <termo>"
		return
	}

	set exacto [lsearch -nocase $text "-exacto"]
	if {$exacto>=0} {
		set text [lreplace $text $exacto $exacto]
		set query $text
	} else {
		set query "*$text*"
	}
	set lista [exec opkg info --nocase "$query"]
	set pacotes [regexp -all -inline -- {Package\: (.*?)\n} $lista]
	if {[llength $pacotes]==0} {
		putnow "privmsg $chan :Não foram encontrados pacotes."
		return
	}
	set visiveis 5
	set tamanhos [regexp -all -inline -- {Size\: (.*?)\n} $lista]
	set versoes [regexp -all -inline -- {Version\: (.*?)\n} $lista]
	set descricoes [regexp -all -inline -- {Description\: (.*?)\n} $lista]

	set i 1
	foreach {m1 pacote} $pacotes {m2 tamanho} $tamanhos {m3 versao} $versoes {m4 desc} $descricoes {
		lappend p($i) $pacote $versao [formatarbytes $tamanho] $desc
		incr i
	}
	unset lista
	set cnome 4
	set ctam 7
	set cver 6
	set cdesc 10

	set lista [lsort -integer [array names p]]

	foreach item $lista {
		lappend lista2 "[string length [lindex $p($item) 0]] $item"
	}
	set lista2 [lsort -integer -index 0 $lista2]
	unset lista
	foreach item $lista2 {
		lappend lista [lindex $item 1]
	}

	set contagem 1
	foreach item $lista {
		if {[string length [lindex $p($item) 0]]>$cnome} {set cnome [string length [lindex $p($item) 0]]}
		if {[string length [lindex $p($item) 1]]>$cver} {set cver [string length [lindex $p($item) 1]]}
		if {[string length [lindex $p($item) 2]]>$ctam} {set ctam [string length [lindex $p($item) 2]]}
		if {[string length [lindex $p($item) 3]]>$cdesc} {set cdesc [string length [lindex $p($item) 3]]}
		if {$contagem==$visiveis} {break}
		incr contagem
	}

	putnow "privmsg $chan :A mostrar [set res [llength $lista]; if {$res>$visiveis} {set a "$visiveis de $res"} {set a "$res"}] resultados"

	putnow "privmsg $chan :[format "\037%-*s  %-*s  %-*s  %-*s" $cnome "Nome" $cver "Versão" $ctam "Tamanho" [if {$cdesc>100} {set a 100} {set cdesc}] "Descrição"]"

	set contagem 1
	foreach item $lista {
		set tdesc ""
		set desc [lindex $p($item) 3]
		foreach palavra [split $desc] {
			if {[expr [string length $tdesc]+[string length $palavra]]<99} {
				append tdesc "$palavra "
			} else {
				if {[llength $lista]>1} {
					append tdesc "…"
				}
				break
			}
		}
		set desc [string range $desc [string length $tdesc] end]

		putnow "privmsg $chan :[subst [regsub -all -nocase $text [format "%-*s  %-*s  %*s  %-*s" $cnome [lindex $p($item) 0] $cver [lindex $p($item) 1] $ctam [lindex $p($item) 2] 100 $tdesc] {\\037&\\037}]]"
		if {[llength $lista]==1 && $desc!=""} {
			set tdesc ""
			foreach palavra [split $desc] {
				if {[expr [string length $tdesc]+[string length $palavra]]<99} {
					append tdesc "$palavra "
				} else {
					putnow "privmsg $chan :[subst [regsub -all -nocase $text [format "%*s  %-*s" [expr $cnome+$cver+$ctam+4] "»" 100 $tdesc] {\\037&\\037}]]"
					set tdesc "$palavra "
				}
			}
			if {$tdesc!=""} {
				putnow "privmsg $chan :[subst [regsub -all -nocase $text [format "%*s  %-*s" [expr $cnome+$cver+$ctam+4] "»" 100 $tdesc] {\\037&\\037}]]"
			}

		}

		if {$contagem>=$visiveis} {break}
		incr contagem
	}

	if {$res>$visiveis} {
		set out "Outros: "
		set pponto 5
		foreach indx [lrange $lista 5 end] {
			if {[expr [string length $out]+[string length [lindex $p($indx) 0]]]<400} {
				lappend out [lindex $p($indx) 0]
				incr pponto
			} else {
				append out " (e mais [expr [llength $lista]-$pponto+1] pacote(s))"
				break
			}
		}
		putnow "privmsg $chan :$out"
	}
}

proc tp:opkg {quem canal text} {
	switch [string tolower [lindex [split $text] 0]] {	
		"update"	{opkgupdate $canal}
		"upgrade"	{opkgupgrade $canal}
		"search"	{opkgsearch $canal [string trim [string range $text 7 end]]}
		default {
			putnow "PRIVMSG $canal :\002UPDATE\002 -> Obter listas de pacotes"
			putnow "PRIVMSG $canal :\002UPGRADE\002 -> Instala os pacotes actualizados"
			putnow "PRIVMSG $canal :\002SEARCH\002 -> Informação sobre um pacote"
		}
	}
}

bind opkg tp:opkg
set dscript(opkg.tcl) "Usa o opkg para actualizar a lista e os pacotes do OpenWRT"
