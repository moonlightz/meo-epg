proc calcprimos {numero} {
 for {set i 2} {$i <= $numero} {incr i} {   set prime 1;  for {set j 2} {$j < $i} {incr j} {  if {[expr $i % $j] == 0} {  set prime 0;  break  }  };  if {$prime == 1} {  lappend primos $i  }  } ; return $primos
}
