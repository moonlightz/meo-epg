proc mapadatas {{ano ""}} {

	#TODO: Criar um peçado de código que devolva o dia exacto das luas
	#carregar o ficheiro de luas
	set fluas [open scripts/luas.txt r]
	set lluas [read -nonewline $fluas]
	close $fluas
	catch {unset ::mcal}

 
	if {$ano==""} {set ano [strftime %Y]}
	#apré-preencher o array

	set mes 0
	set ldias "31 [if {[expr $ano%4]<1} {set a 29} {set a 28}] 31 30 31 30 31 31 30 31 30 31"
	foreach ndias $ldias {
		incr mes
		foreach linha [split $lluas "\n"] {
			set dataluas [lrange $linha 1 end]
			foreach {luames luaano} $dataluas {
				if {$luames==$mes && $luaano==$ano} {
					set luas [string map {A " QC " B " LC " C " QM " D " LN "} [lindex $linha 0]]
					break
				}
			}
		}
		for {set dia 1} {$dia<=$ndias} {incr dia} {
			if {[lsearch $luas $dia]>0} {
				set ::mcal($dia/$mes) [lindex $luas [lsearch $luas $dia]-1]
			} else {
		   		set ::mcal($dia/$mes) -
			}
			switch "$dia/$mes" {
				"1/1"	{lappend ::mcal($dia/$mes) F "Dia de Ano Novo"}
				"6/1"	{lappend ::mcal($dia/$mes) 6 "Dia de Reis"}
				"14/2"	{lappend ::mcal($dia/$mes) 14 "Dia dos Namorados"}
				"19/3"	{lappend ::mcal($dia/$mes) 19 "Dia do Pai"}
				"25/4"	{lappend ::mcal($dia/$mes) F "25 de Abril - Dia da Liberdade"}
				"1/5"	{lappend ::mcal($dia/$mes) F "Dia do Trabalhador"}
				"1/6"	{lappend ::mcal($dia/$mes) 1 "Dia Mundial da Criança"}
				"10/6"	{lappend ::mcal($dia/$mes) F "Dia de Portugal"}
				"15/8"	{lappend ::mcal($dia/$mes) F "Assunção de Nossa Senhora"}
				"5/10"	{lappend ::mcal($dia/$mes) F "Implantação da República"}
				"1/11"	{lappend ::mcal($dia/$mes) F "Dia de Todos os Santos"}
				"1/12"	{lappend ::mcal($dia/$mes) F "Restauração da Independência"}
				"8/12"	{lappend ::mcal($dia/$mes) F "Dia da Imaculada Conceição"}
				"25/12"	{lappend ::mcal($dia/$mes) N "Natal"}
				default {}
			}
		}			
	}

	#Páscoa - O primeiro Domingo após a Lua Cheia após 21/3
	set found213 0
	set foundLC 0
	set founddiamae 0
	set mes 3
	set sday 21
	
	foreach ndias $ldias {
	 	for {set dia $sday} {$dia<=$ndias} {incr dia} {
			if {$dia==21 && $mes==3} {
				set found213 1
				continue
			}
			if {$found213} {
				if {[lindex $::mcal($dia/$mes) 0]=="LC"} {
					set foundLC 1
					continue
				}
				if {$foundLC} {
					if {[clock format [clock scan $dia/$mes/$ano -format %d/%m/%Y] -format %A]=="Sunday"} {
						lappend ::mcal($dia/$mes) P Páscoa

						set sextasanta [string trimleft [string map {/0 /} [clock format [clock add [clock scan $dia/$mes/$ano -format %d/%m/%Y] -2 days] -format "%d/%m"]] "0"]
						lappend ::mcal($sextasanta) F "Sexta-feira Santa"

						set carnaval [string trimleft [string map {/0 /} [clock format [clock add [clock scan $dia/$mes/$ano -format %d/%m/%Y] -47 days] -format "%d/%m"]] "0"]
						lappend ::mcal($carnaval) C "Carnaval"

						set cinzas [string trimleft [string map {/0 /} [clock format [clock add [clock scan $dia/$mes/$ano -format %d/%m/%Y] -46 days] -format "%d/%m"]] "0"]
						lappend ::mcal($cinzas) [lindex [split $cinzas /] 0] "Quarta-feira de Cinzas"
					
						set cdeus [string trimleft [string map {/0 /} [clock format [clock add [clock scan $dia/$mes/$ano -format %d/%m/%Y] 60 days] -format "%d/%m"]] "0"]
						lappend ::mcal($cdeus) F "Corpo de Deus"

						set dramos [string trimleft [string map {/0 /} [clock format [clock add [clock scan $dia/$mes/$ano -format %d/%m/%Y] -7 days] -format "%d/%m"]] "0"]
						lappend ::mcal($dramos) [lindex [split $dramos /] 0] "Domingo de Ramos"

						set found213 0
					}
				}
			}

			if {$mes==3 && $dia>=25 && [clock format [clock scan $dia/$mes/$ano -format %d/%m/%Y] -format %A]=="Sunday"} {
				lappend ::mcal($dia/$mes) $dia "Início do Horário de Verão"
			}

			if {$mes==10 && $dia>=25 && [clock format [clock scan $dia/$mes/$ano -format %d/%m/%Y] -format %A]=="Sunday"} {
				lappend ::mcal($dia/$mes) $dia "Início do Horário de Inverno"
			}

			if {$mes==5} {
				if {[clock format [clock scan $dia/$mes/$ano -format %d/%m/%Y] -format %A]=="Sunday" && !$founddiamae} {
					lappend ::mcal($dia/$mes) $dia "Dia da Mãe"
					set founddiamae 1
				}
			}
		}
		incr mes
		if {$mes==11} {break}
		set sday 1
	}
}
