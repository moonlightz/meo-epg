<?php

//System name
$sys_name['lang_name'] = 'Português (Portugal)';
$sys_name['lang_code'] = 'pt-pt';
$sys_name['lang_autor'] = 'moonlightz';
$sys_name['bytes'] = 'bytes';
$sys_name['byte'] = 'byte';
$sys_name['loading'] = 'A carregar dados';

//index page
$index_name['description'] = 'Este projecto ajuda-o a apenas descarregar ficheiros UUP ou descarregar e criar uma image ISO num clique.';
$index_name['seltype'] = 'Seleccionar tipo';
$index_name['selversion'] = 'Seleccionar versão';
$index_name['sellang'] = 'Seleccionar idioma';
$index_name['seledition'] = 'Seleccionar edição';
$index_name['seltypedown'] = 'Seleccionar tipo de descarga';
$index_name['totalfile'] = 'Total de ficheiros disponíveis:';
$index_name['totalvolume'] = 'Total de volume de ficheiros:';
$index_name['genlink'] = 'Número geral de links gerados:';

//GetFiles
$getfiles_name['copy_url'] = 'O link constante foi copiado com sucesso.';
$getfiles_name['error_id'] = 'O parâmetro requerido não foi encontrado ;(';
//$getfiles_name['temporary'] = 'Temporário';
//$getfiles_name['link_expires'] = 'de acordo com o link foi gerado (Link expira a:';
$getfiles_name['temporary'] = 'Ficheiro';
$getfiles_name['link_expires'] = 'de acordo com o link foi gerado';
$getfiles_name['error_lang'] = 'Erro!!! Não encontrámos quaisquer dados nestes parâmetros.';
$getfiles_name['file'] = 'Ficheiro';
$getfiles_name['expires'] = 'Expira';
$getfiles_name['size'] = 'Tamanho';
$getfiles_name['attention'] = 'Atenção';
$getfiles_name['attention_txt'] = 'Estes ficheiros estão localizados nos servidores da Microsoft e têm um tempo limite para descarregamento. Despache-se a descarregar (o tempo de referência é de 10 minutos até 4 horas, dependendo do tamanho). Utilize <b>Internet Download Manager</b> ou outro gestor para descarregamento rápido.<br>Boa sorte.';
$getfiles_name['all_links'] = 'Todos os links para o seu caso:';
$getfiles_name['down_link'] = 'Links de descarregamento';
$getfiles_name['file_renaming'] = 'Renomeação de ficheiro:';
$getfiles_name['down_bat'] = 'Descarregar ficheiro bat';
$getfiles_name['sha1_checksum'] = 'Checksums de SHA-1:';
$getfiles_name['down_crc'] = 'Descarregar ficheiro de checksum';
$getfiles_name['creationISO_head'] = $getfiles_name['temporary'].' <b>creatingISO.cmd</b> '.$getfiles_name['link_expires'];
$getfiles_name['creation10X_head'] = $getfiles_name['temporary'].' <b>creating10X.cmd</b> '.$getfiles_name['link_expires'];
$getfiles_name['creationISO_cmd_txt1'] = 'Este script irá ajudá-lo imediatamente a criar directamente o ficheiro ISO com aquelas edições que especificou no caso de uma escolha. Para este objectivo, copie este ficheiro no arquivo descompactado (se não tiver tal arquivo, então pode descarregá-lo deste link:';
$getfiles_name['creationISO_cmd_txt2'] = 'e para lançar o script';
$getfiles_name['creationISO_cmd_txt_new'] = 'Este script irá ajudá-lo a criar directamente o ficheiro ISO com aquelas edições que especificou no caso de uma escolha.';
$getfiles_name['creationISO_zip_txt'] = 'Descomprima o arquivo, depois corra creatingISO.cmd e espere que sejam descarregados ficheiros necessários e irá ser criado o ficheiro ISO (normalmente esta operação demora entre 5 e 40 minutos - depende do poder do seu PC e do tipo de Internet).';
$getfiles_name['error_gen'] = 'Ocorreu um erro.';
$getfiles_name['down_aria2_head'] = $getfiles_name['temporary'].' <b>downUUP.cmd</b> '.$getfiles_name['link_expires'];
$getfiles_name['down_aria2_txt1'] = 'Por meio deste script - pode descarregar apenas os ficheiros UUP.';
//$getfiles_name['down_aria2_txt1'] = 'Por meio deste script - pode descarregar apenas os ficheiros UUP. Para isto, é necessário que defina Aria2.';
$getfiles_name['down_aria2_txt2'] = 'Pode descarregar e instalar esta aplicação de acordo com este link:';
$getfiles_name['updateOS_head'] = $getfiles_name['temporary'].' <b>updateOS.cmd</b> '.$getfiles_name['link_expires'];
$getfiles_name['updateOS_txt'] = 'Com este script - pode actualizar o seu sistema para m compilação pedida (não presta se quiser voltar atrás).';
//$getfiles_name['updateOS_txt'] = 'Com este script - pode actualizar o seu sistema para a compilação pedida (não presta se quiser voltar atrás). É necessário que instale o Aria2.';
$getfiles_name['full_build'] = 'Número completo da compilação';
$getfiles_name['msbuild'] = 'Detalhes acerca da Compilação:';

//Statistics
$stats['statistics'] = 'Estatísticas do Serviço';
$stats['activity'] = 'Actividade';
$stats['views'] = 'Visualizações';
$stats['visits'] = 'Visitas';
$stats['gen_zip'] = 'Arquivos ZIP<br>gerados';
$stats['gen_cmd'] = 'Ficheiros CMD<br>gerados';
$stats['gen_url'] = 'Links de ficheiros<br>da Microsoft<br>gerados';
$stats['60_min'] = 'na última hora';
$stats['today'] = 'hoje';
$stats['yesterday'] = 'ontem';
$stats['all_time'] = 'tudo';

//List language
$lang_name['all'] = 'Todos os idiomas';
$lang_name['cuml'] = 'Actualização comulativa';
$lang_name['holographic'] = 'Microsoft-Windows-Holographic-Desktop-FOD-Package';
$lang_name['ar-sa'] = 'Árabe';
$lang_name['pt-br'] = 'Português Brasileiro';
$lang_name['bg-bg'] = 'Bulgaro';
$lang_name['zh-cn'] = 'Chinês (Simplificado)';
$lang_name['zh-tw'] = 'Chinês (Tradicional)';
$lang_name['hr-hr'] = 'Croata';
$lang_name['cs-cz'] = 'Checo';
$lang_name['da-dk'] = 'Dinamarquês';
$lang_name['nl-nl'] = 'Neerlandês';
$lang_name['en-gb'] = 'Inglês (Reino Unico)';
$lang_name['en-us'] = 'Inglês (Estados Unidos)';
$lang_name['et-ee'] = 'Estónio';
$lang_name['fi-fi'] = 'Filandês';
$lang_name['fr-fr'] = 'Francês';
$lang_name['fr-ca'] = 'Francês Canadiano';
$lang_name['de-de'] = 'Alemão';
$lang_name['el-gr'] = 'Grego';
$lang_name['he-il'] = 'Hebreu';
$lang_name['hu-hu'] = 'Hungaro';
$lang_name['it-it'] = 'Italiano';
$lang_name['ja-jp'] = 'Japonês';
$lang_name['ko-kr'] = 'Coreano';
$lang_name['lv-lv'] = 'Letão';
$lang_name['lt-lt'] = 'Lituano';
$lang_name['nb-no'] = 'Norueguês';
$lang_name['pl-pl'] = 'Polaco';
$lang_name['pt-pt'] = 'Português';
$lang_name['ro-ro'] = 'Romeno';
$lang_name['ru-ru'] = 'Russo';
$lang_name['sr-latn-rs'] = 'Sérvio (Latim)';
$lang_name['sk-sk'] = 'Eslovaco';
$lang_name['sl-si'] = 'Esloveno';
$lang_name['es-es'] = 'Espanhol';
$lang_name['es-mx'] = 'Espanhol (México)';
$lang_name['sv-se'] = 'Sueco';
$lang_name['th-th'] = 'Tailandês';
$lang_name['tr-tr'] = 'Turco';
$lang_name['uk-ua'] = 'Ucraniano';

// List download type
$down_type_name['creatingISO_zip'] = 'Descarregar compilador ISO em UmClique! (descomprimir -> CORRER creatingISO.cmd)';
$down_type_name['creatingISO_cmd'] = 'Descarregar compilador ISO em UmClique! (correr ficheiro CMD descarregado)';
$down_type_name['creating10X_cmd'] = 'Descarregar compilador FFU & VHDX em UmClique! (correr ficheiro CMD descarregado)';
$down_type_name['down_aria2'] = 'Descarregar ficheiros UUP via Aria2';
$down_type_name['updateOS'] = 'Actualizar OS em UmClique!';
$down_type_name['default'] = 'Geração de ficheiros predefinida';

// List type
$type_name['1'] = 'Windows (Versão final)';
$type_name['2'] = 'Windows (Versão Insider)';
$type_name['3'] = 'Actualização Cumulativa para Windows 10/11';

//List Edition
$edition_name['all'] = 'Todas as Edições';
$edition_name['language'] = 'Apenas ficheiros de idioma';
if ($build <= 21950) {
    $edition_name['lite'] = 'Windows 10X';
    $edition_name['CLOUD'] = 'Windows 10 Cloud (S)';
    $edition_name['CLOUDN'] = 'Windows 10 Cloud N (S N)';
    $edition_name['CLOUDE'] = 'Windows 10 Lean  (CloudE)';
    $edition_name['CLOUDEN'] = 'Windows 10 Lean N (CloudE N)';
    $edition_name['CORESINGLELANGUAGE'] = 'Windows 10 Home Single Language';
    $edition_name['CORECOUNTRYSPECIFIC'] = 'Windows 10 Home China';
    $edition_name['CORE'] = 'Windows 10 Home';
    $edition_name['COREN'] = 'Windows 10 Home N';
    $edition_name['PROFESSIONAL'] = 'Windows 10 Professional';
    $edition_name['PROFESSIONALN'] = 'Windows 10 Professional N';
    $edition_name['PROFESSIONALEDUCATION'] = 'Windows 10 Professional for Education';
    $edition_name['PROFESSIONALEDUCATIONN'] = 'Windows 10 Professional for Education N';
    $edition_name['PROFESSIONALSINGLELANGUAGE'] = 'Windows 10 Professional Single Language';
    $edition_name['PROFESSIONALWORKSTATION'] = 'Windows 10 Professional for Workstation';
    $edition_name['PROFESSIONALWORKSTATIONN'] = 'Windows 10 ПProfessional for Workstation N';
    $edition_name['PPIPRO'] = 'Windows 10 Team (PPIPro)';
    $edition_name['EDUCATION'] = 'Windows 10 Education';
    $edition_name['EDUCATIONN'] = 'Windows 10 Education N';
    $edition_name['ENTERPRISE'] = 'Windows 10 Enterprise';
    $edition_name['ENTERPRISEN'] = 'Windows 10 Enterprise N';
    $edition_name['ENTERPRISEEVAL'] = 'Windows 10 Enterprise (teste 90 dias)';
    $edition_name['ENTERPRISENEVAL'] = 'Windows 10 Enterprise N (teste 90 dias)';
    $edition_name['ENTERPRISES'] = 'Windows 10 Enterprise with LTSB';
    $edition_name['ENTERPRISESN'] = 'Windows 10 Enterprise com LTSB N';
}
if ($build >= 21950) {
    $edition_name['lite'] = 'Windows 11X';
    $edition_name['CLOUD'] = 'Windows 11 Cloud (S)';
    $edition_name['CLOUDN'] = 'Windows 11 Cloud N (S N)';
    $edition_name['CLOUDE'] = 'Windows 11 Lean  (CloudE)';
    $edition_name['CLOUDEN'] = 'Windows 11 Lean N (CloudE N)';
    $edition_name['CORESINGLELANGUAGE'] = 'Windows 11 Home Single Language';
    $edition_name['CORECOUNTRYSPECIFIC'] = 'Windows 11 Home China';
    $edition_name['CORE'] = 'Windows 11 Home';
    $edition_name['COREN'] = 'Windows 11 Home N';
    $edition_name['PROFESSIONAL'] = 'Windows 11 Professional';
    $edition_name['PROFESSIONALN'] = 'Windows 11 Professional N';
    $edition_name['PROFESSIONALEDUCATION'] = 'Windows 11 Professional for Education';
    $edition_name['PROFESSIONALEDUCATIONN'] = 'Windows 11 Professional for Education N';
    $edition_name['PROFESSIONALSINGLELANGUAGE'] = 'Windows 11 Professional Single Language';
    $edition_name['PROFESSIONALWORKSTATION'] = 'Windows 11 Professional for Workstation';
    $edition_name['PROFESSIONALWORKSTATIONN'] = 'Windows 11 ПProfessional for Workstation N';
    $edition_name['PPIPRO'] = 'Windows 11 Team (PPIPro)';
    $edition_name['EDUCATION'] = 'Windows 11 Education';
    $edition_name['EDUCATIONN'] = 'Windows 11 Education N';
    $edition_name['ENTERPRISE'] = 'Windows 11 Enterprise';
    $edition_name['ENTERPRISEN'] = 'Windows 11 Enterprise N';
    $edition_name['ENTERPRISEEVAL'] = 'Windows 11 Enterprise (teste 90 dias)';
    $edition_name['ENTERPRISENEVAL'] = 'Windows 11 Enterprise N (teste 90 dias)';
    $edition_name['ENTERPRISES'] = 'Windows 11 Enterprise with LTSB';
    $edition_name['ENTERPRISESN'] = 'Windows 11 Enterprise with LTSB N';
}
$edition_name['SERVERDATACENTER'] = 'Windows Server Datacenter';
$edition_name['SERVERDATACENTERCORE'] = 'Windows Server Datacenter (Core)';
$edition_name['SERVERSTANDARD'] = 'Windows Server Standard';
$edition_name['SERVERSTANDARDCORE'] = 'Windows Server Standard (Core)';
$edition_name['SERVERAZURESTACKHCICOR'] = 'Azure Stack HCI (Core)';
$edition_name['SERVERTURBINECORE'] = 'Windows Server Datacenter Azure Edition (Core)';
$edition_name['SERVERTURBINE'] = 'Windows Server Datacenter Azure Edition';