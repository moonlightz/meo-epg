# Compare a time pattern like "1*:20", "12:3*", "*:20" with the current time
proc checkTime {pattern {now ""}} {
    # If no time is supplied, use current system time
    if {$now eq ""} {
        set now [clock format [clock seconds] -format "%H:%M"]
    }

    # Split times
    lassign [split $pattern :] ph pm
    lassign [split $now     :] nh nm

    # Expand pattern into numeric min/max ranges
    # Example: "1*" -> 10..19, "*" -> 0..59, "34" -> 34..34
    proc range {p max} {
        if {$p eq "*"} {
            return [list 0 $max]
        } elseif {[string match "*\**" $p]} {
            set base [string map {* 0} $p]
            set lo $base
            set hi [string map {* 9} $p]
            return [list $lo $hi]
        } else {
            return [list $p $p]
        }
    }

    lassign [range $ph 23] hmin hmax
    lassign [range $pm 59] mmin mmax

    # Convert everything to minutes for easy comparison
    set nowMin [expr {$nh * 60 + $nm}]
    set minMin [expr {$hmin * 60 + $mmin}]
    set maxMin [expr {$hmax * 60 + $mmax}]

    if {$nowMin < $minMin} {
        return "not passed"
    } elseif {$nowMin > $maxMin} {
        return "passed"
    } else {
        return "on time"
    }
}
