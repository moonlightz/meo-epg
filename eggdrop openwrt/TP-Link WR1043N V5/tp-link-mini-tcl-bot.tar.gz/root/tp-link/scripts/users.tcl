proc listarusers {} {
	package require inifile
	set fi [ini::open config/users.ini]
	set users [ini::sections $fi]
	ini::close $fi
	return $users
}

proc users {{arg1 ""} {arg2 ""}} {
	if {$arg1==""} {
		return [listarusers]
    } else {
		return [regexp $arg1 [listarusers]]
	}
}
