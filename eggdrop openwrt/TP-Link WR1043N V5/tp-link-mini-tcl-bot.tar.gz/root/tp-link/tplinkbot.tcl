#!/usr/bin/tclsh

set netstat [exec netstat]
foreach linha [split $netstat \n] {
	if {[string match *192.168.1.250:60001*ESTABLISHED* $linha]} {
		puts "A sair" 
		return
	}
}
unset netstat
# captura o stdout
proc stdout { switch { file "" } } {
    if { ! [ llength [ info command __puts ] ] && \
           [ string equal off $switch ] } {
       rename puts __puts
       if { [ string length $file ] } {
          eval [ subst -nocommands {proc puts { args } {
             set fid [ open $file a+ ]
             if { [ llength \$args ] > 1 && \
                  [ lsearch \$args stdout ] == 0 } {
                set args [ lreplace \$args 0 0 \$fid ]
             } elseif {  [ llength \$args ] == 1 } {
                set args [ list \$fid \$args ]
             }
             if { [ catch {
                eval __puts \$args
             } err ] } {
                close \$fid
                return -code error \$err
             }
             close \$fid
          }} ]
       } else {
          eval [ subst -nocommands {proc puts { args } {
             if { [ llength \$args ] > 1 && \
                  [ lsearch \$args stdout ] == 0 || \
                  [ llength \$args ] == 1 } {
                # no-op
             } else {
                eval __puts \$args
             }
          }} ]   
       }
    } elseif { [ llength [ info command __puts ] ] && \
               [ string equal on $switch ] } {
       rename puts {}
       rename __puts puts
    }
}
# # # # # # # # # # # # # # # # # #
proc strftime {format {time {}}} {
	if {$time eq {}} {
		set time [clock seconds]
	}
	clock format $time -format $format
}

set a [exec ps | grep tclsh]
set procs [regexp -all -inline -- {(.*?) root .* tclsh tplinkbot.tcl} $a]
foreach {mproc iproc} $procs {
	set iproc [string trim $iproc]
	if {$iproc==""} {continue}
	if {$iproc!=[pid]} {
		exec kill $iproc
		puts stdout "Processo $iproc terminado."
	}
}

set fichlog "/tmp/tplink.log"
set botnick "TP-Link"
set botident "tplink"

if {[lindex $argv 0] ne "-dorealprocessing"} {
	set command [list [info nameofexecutable]]
	# A starpack doesn't use a script parameter on the command line
	if {![info exists ::starkit::mode] || $starkit::mode ne "starpack"} {
		lappend command [info script]
	}
	eval exec $command -dorealprocessing $argv >/dev/null &
	exit
}
stdout off $fichlog


puts "A lançar $botnick ... (Pid: [pid])"


proc instalarpacotes {} {
	foreach fich [glob packages/*.tar.gz] {
		if {![file exists /usr/lib/tcl8.6/[string range $fich 0 [string first ".tar.gz" $fich]-1]]} {
			exec tar zxf $fich -C /usr/lib/tcl8.6/
		}
	}
}
instalarpacotes

regexp {PRETTY_NAME="(.*?)"\n} [exec cat /etc/os-release] -> openwrtversao
regexp {VERSION="(.*?)"\n} [exec cat /etc/os-release] -> openwrtnversao
regexp {"name": "(.*?)"\n} [exec cat /etc/board.json] -> nomerouter
set gecos "$nomerouter @ $openwrtversao"

#vars globais
set permrede "y"
set lcanais "#konoha"


proc sleep {time} {
	global sleeptime
	after $time set sleeptime 1
	vwait sleeptime
}

proc bind {trigger nomeproc} {
	global lbinds
	dict set lbinds $trigger $nomeproc
}

proc binds {} {
	global lbinds
	append listabinds "COMANDO      PROC (TCL)\n"
	foreach chave [dict keys $lbinds] {
		append listabinds [format "%-11s  %-11s\n" $chave [dict get $lbinds $chave]]
	}
	string trimright $listabinds "\n"
}

proc logtime {} {
	return "\[[string map {Feb Fev Apr Abr May Mai Aug Ago Sep Set Oct Out Dec Dez} [strftime "%d/%b %H:%M:%S"]]\]"
}

##########telnet###############################
#set telnet [socket -server  9999]
#fconfigure $telnet -blocking 0 -buffering none
#  fileevent $sock readable "handleInput $sock"
########################################
###############################
set botligar 1
set in ""
set serverindex 1

while {$permrede=="y"} {

	if {!$botligar} {
		set in [gets $fd]
	}
	if {$in=="" || $botligar} {
		source config/servers.tcl
		while 1 {
			catch {close $fd}
			set dstaddr [lindex $server($serverindex) 0]
			set dstport [lindex $server($serverindex) 1]
			puts stdout "[logtime] --- A ligar a $dstaddr:$dstport ..."
			if {[catch {set fd [socket -async $dstaddr $dstport]} erro]} {
				puts stdout "[logtime] !!! Não foi possivel ligar a $dstaddr: $erro"
			} else {
				puts stdout "Ligado!!!"
				break
			}

			incr serverindex
			if {$serverindex>[llength [array names server]]} {
				set serverindex 1
			}
			#puts stdout ">[file channels]<"
		}
		sleep 3000
		if {[lindex $server($serverindex) 2]!=""} {
			puts $fd "PASS [lindex $server($serverindex) 2]"
				flush $fd
		}
		puts $fd "NICK $botnick"
		flush $fd
		puts $fd "USER $botident \"\" \"\" :$gecos"
		flush $fd
		set botligar 0
	}

	source listascripts.tcl
	foreach botscript $botscripts {
		set botscript "scripts/$botscript"
		if {[catch {source $botscript} error]} {
			set error [tr $error]
			puts stdout "(x) \[$botscript\] $error"
			putnow "PRIVMSG #konoha :\0030,4Ⓧ\0038,1 \[$botscript\]: $error"
		}
	}

	foreach chave [dict keys $lbinds] {
		if {[lindex [split $texto] 0]==$chave} {
			if {[string first " " $texto]>-1} {set argx [string range $texto [string first " " $texto]+1 end]} {set argx ""}
			if {[catch {[dict get $lbinds $chave] $quem $canal $argx} error]} {
				set error [tr $error]
				puts stdout "(x) $error"
				putnow "PRIVMSG #konoha :\0030,4Ⓧ\0038,1 $error"
			}
		}
	}
	if {[info exists chave]} {unset chave}
	catch {error botscript}
	puts stdout "[logtime] $in"
	if {[string range $in 0 5]=="PING :"} {
		set resposta "PONG [string range $in 6 end]"
		putnow $resposta
		puts stdout "[logtime] -> $resposta"
		unset resposta
	}
}
close $fd
