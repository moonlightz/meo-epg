proc tabelacaracteres {enc} {
foreach i "0 1 2 3 4 5 6 7 8 9 A B C D E F" {set out ""; foreach j "0 1 2 3 4 5 6 7 8 9 A B C D E F" {append out "\\x$i$j"}; putnow "privmsg #code :[encoding convertfrom $enc [subst $out]]"}
}
