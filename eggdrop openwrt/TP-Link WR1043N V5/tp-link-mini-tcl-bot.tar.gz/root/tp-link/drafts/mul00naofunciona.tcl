proc schoolMultiply {num1 num2} {

    # Save original values
    set orig1 $num1
    set orig2 $num2

    # Detect sign of final result
    set negative 0
    if {($num1 < 0 && $num2 >= 0) || ($num1 >= 0 && $num2 < 0)} {
        set negative 1
    }

    # Work with absolute values
    set num1 [expr {abs($num1)}]
    set num2 [expr {abs($num2)}]

    # Convert to string
    set s1 $num1
    set s2 $num2

    # Count decimal places
    set dec1 0
    set dec2 0

    if {[regexp {\.} $s1]} {
        set dec1 [expr {[string length $s1] - [string first "." $s1] - 1}]
        regsub {\.} $s1 "" s1
    }
    if {[regexp {\.} $s2]} {
        set dec2 [expr {[string length $s2] - [string first "." $s2] - 1}]
        regsub {\.} $s2 "" s2
    }

    set totalDec [expr {$dec1 + $dec2}]

    # Reverse second number for step multiplication
    set len2 [string length $s2]
    set partials {}

    for {set i [expr {$len2-1}]} {$i >= 0} {incr i -1} {
        set digit [string index $s2 $i]
        if {$digit eq ""} continue

        set part [expr {$s1 * $digit}]
        append part [string repeat "0" [expr {$len2-1-$i}]]
        lappend partials $part
    }

    # Final result (integer form)
    set result 0
    foreach p $partials {
        set result [expr {$result + $p}]
    }

    # Insert decimal point
    if {$totalDec > 0} {
        set resultStr [format "%0*d" [expr {$totalDec+1}] $result]
        set pos [expr {[string length $resultStr] - $totalDec}]
        set resultStr "[string range $resultStr 0 [expr {$pos-1}]].[string range $resultStr $pos end]"
    } else {
        set resultStr $result
    }

    if {$negative} {
        set resultStr "-$resultStr"
    }

    # Determine print width
    set width [expr {max([string length $s1], [string length $s2]+1, [string length $resultStr]) + 2}]

    # Print first number
    puts "|[format %*s $width $orig1]|"

    # Print second number with x
    puts "|[format %*s $width "x$orig2"]|"

    # Print partial products
    set shift 0
    foreach p $partials {
        puts "|[format %*s $width $p]|"
        incr shift
    }

    # Print separator line
    puts "|[string repeat "-" $width]|"

    # Print final result
    puts "|[format %*s $width $resultStr]|"
}
