proc columnize {lst {columns 8}} {
    set len [llength $lst]
    set nrows [expr {int(ceil($len / (0.0 + $columns)))}]
    set cols [list]
    for {set n 0} {$n < $len} {incr n $nrows} {
        lappend cols [lrange $lst $n [expr {$n + $nrows - 1}]]
    }
    for {set n 0} {$n < $nrows} {incr n} {
        set row [list]
        foreach col $cols {
            lappend row [lindex $col $n]
        }
        putnow "PRIVMSG #CODE :[join $row " "]"
    }
}
