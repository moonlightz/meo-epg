proc tp:cal2 {quem chan text} {
	set ano [lindex $text 0]
	if {$ano==""} {set ano [strftime "%Y"]}
	if {![string is integer -strict $ano]} {
		putnow "privmsg $chan :O ano tem de ser um número inteiro."
		return
	}
	
	mapadatas $ano
	set header "\0030,1   $ano  [string repeat " \0037,2Do\0030,2 2ª 3ª 4ª 5ª 6ª Sá" 6]"
	putnow "PRIVMSG $chan :[string range $header 0 172]"
	for {set m 1} {$m<=12} {incr m} {
		switch $m {
			1	{set nome "Janeiro"; set dias 31}
			2	{set nome "Fevereiro"; if {[expr $ano%4]==0} {set dias 29} {set dias 28}}
			3	{set nome "Março"; set dias 31}
			4	{set nome "Abril"; set dias 30}
			5	{set nome "Maio"; set dias 31}
			6	{set nome "Junho"; set dias 30}
			7	{set nome "Julho"; set dias 31}
			8	{set nome "Agosto"; set dias 31}
			9	{set nome "Setembro"; set dias 30}
			10	{set nome "Outubro"; set dias 31}
			11	{set nome "Novembro"; set dias 30}
			12	{set nome "Dezembro"; set dias 31}
		}
		set ldias [lrepeat 38 " "]
		set ds [strftime %w [clock scan "1/$m/$ano" -format "%d/%N/%Y"]]

		for {set dx 1} {$dx<=$dias} {incr dx} {
			set dia $dx
			if {[lindex $::mcal($dia/$m) 1]!=""} {
				set dia [lindex $::mcal($dia/$m) 1]
			}
			if {[strftime %d/%m/%Y]=="[format "%02d" $dx]/[format "%02d" $m]/$ano"} {
				set dia "[format "\026%*s\026" 2 [subst \$dia]]"
			}
			set ldias [lreplace $ldias [expr $dx+$ds-1] [expr $dx+$ds-1] $dia]
		}

		set linha [format "\0030,2%-9s\003" $nome]

		set ds 0
		for {set dl 0} {$dl<37} {incr dl} {
			append linha "[if {$ds==0} {set a "\0037,17 "} {set a "\0030 "}][format "%*s" 2 [lindex $ldias $dl]]"
			incr ds
			if {$ds>6} {set ds 0}
		}
		putnow "PRIVMSG $chan :$linha "
	}
	catch {unset ::mcal}
}

bind cal2 tp:cal2
set dscript(cal2.tcl) "Calendário mesa"
