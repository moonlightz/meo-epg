proc sstring {s1 s2} {
	regexp {^(.*?)-(?=\d)} $s1 -> name
	set v1 [string range $s1 [expr {[string length $name] + 1}] end]
	set v2 [string range $s2 [expr {[string length $name] + 1}] end]

	return "$name $v1 $v2"
}

proc apkupdate {chan} {
	set lelemopenwrt [regexp -all -inline {<tr><td class=\"n\"><a href=\"(.*?)\">(.*?)</a>/</td><td class=\"s\">-</td><td class=\"d\">(.*?)</td></tr>} [exec wget -q -O - https://downloads.openwrt.org/releases/]]
	foreach {m1 m2 versao data} $lelemopenwrt {
		if {![string match "fail*" $versao] && ![string match "pack*" $versao]} {
			lappend lversoes $versao
		}
	}
	for {set i 0} {$i<[llength $lversoes]} {incr i} {
		if {[string match "*.0" [lindex $lversoes $i]] && [string match "*.0-rc*" [lindex $lversoes $i+1]]} {
			set a [lindex $lversoes $i]
			set lversoes [lreplace $lversoes $i $i [lindex $lversoes $i+1]]
			set lversoes [lreplace $lversoes $i+1 $i+1 $a]
		}
	}
#Downloading https://downloads.openwrt.org/releases/23.05.0-rc3/packages/mips_24kc/base/ucode_2023-06-06-c7d84aae-1_mips_24kc.ipk
	set novaversao [lindex $lversoes end]
	if {$novaversao!=$::openwrtnversao} {
		putnow "privmsg $chan :Existe uma nova versão de firmware! Versão actual: \002$::openwrtnversao\002  Versão disponível: \002$novaversao\002"
		putnow "privmsg $chan :Ficheiro: https://downloads.openwrt.org/releases/$novaversao/targets/ath79/generic/openwrt-$novaversao-ath79-generic-tplink_tl-wr1043n-v5-squashfs-sysupgrade.bin"
	}

	putnow "PRIVMSG $chan :A descarregar a lista ..."
	set apk [exec apk update]
	putnow "PRIVMSG $chan :A obter a lista de actualizações ..."
	set lpacotes [exec apk list --upgradeable]
	set cnome 0; set cnova 0; set cvelha 0
	unset i
	foreach pacote [split $lpacotes "\n"] {
		incr i
		regexp {(.*?) (.*?) \{(.*?)\} \((.*?)\) \[upgradable from: (.*?)\]} $pacote -> pnovo arch sector lic pvelho
		lassign [sstring $pnovo $pvelho] nome vnova vvelha
		if {[string length $nome]>$cnome} {set cnome [string length $nome]}
		if {[string length $vnova]>$cnova} {set cnova [string length $vnova]}
		if {[string length $vvelha]>$cvelha} {set cvelha [string length $vvelha]}
	}

    foreach pacote [split $lpacotes \n] {
		regexp {(.*?) (.*?) \{(.*?)\} \((.*?)\) \[upgradable from: (.*?)\]} $pacote -> pnovo arch sector lic pvelho
		lassign [sstring $pnovo $pvelho] nome vnova vvelha
		append out [format "%-*s   %-*s >> %-*s" $cnome $nome $cvelha $vvelha $cnova $vnova]\n
	}

	if {![info exists out]} {
		putnow "privmsg $chan :Não há actualizações."
		return
	} else {
		putnow "PRIVMSG $chan :$out"
	}
	if {$i!=[llength [split $lpacotes \n]]} {
		putnow "privmsg $chan :!!!! oh oh .... a contagem não coincide... [llength [split $lpacotes \n]] vs $i"
	}
	putnow "PRIVMSG $chan :[switch [llength [split $lpacotes "\n"]] {0 {set a "Não há actualizações disponíveis."} 1 {set a "1 actualização disponível."} default {set a "[llength [split $lpacotes \n]] actualizações disponiveis."}}]"
}

proc apkupgrade {chan} {
	putnow "privmsg $chan :A actualizar ..."
	set resultado [exec apk upgrade]
set fp [open apkupgrade.txt w+]
puts $fp $resultado
close $fp
putnow "privmsg $chan :Guardado"
	putnow "privmsg $chan :[tr $resultado]"
}

proc apksearch {chan text} {
	if {$text==""} {
		putnow "PRIVMSG $chan :Utilização: apk search <termo>"
		return
	}

	set exacto [lsearch -nocase $text "-exacto"]
	if {$exacto>=0} {
		set text [lreplace $text $exacto $exacto]
		set query $text
	} else {
		set query "*$text*"
	}
	set lista [exec apk info --nocase "$query"]
	set pacotes [regexp -all -inline -- {Package\: (.*?)\n} $lista]
	if {[llength $pacotes]==0} {
		putnow "privmsg $chan :Não foram encontrados pacotes."
		return
	}
	set visiveis 5
	set tamanhos [regexp -all -inline -- {Size\: (.*?)\n} $lista]
	set versoes [regexp -all -inline -- {Version\: (.*?)\n} $lista]
	set descricoes [regexp -all -inline -- {Description\: (.*?)\n} $lista]

	set i 1
	foreach {m1 pacote} $pacotes {m2 tamanho} $tamanhos {m3 versao} $versoes {m4 desc} $descricoes {
		lappend p($i) $pacote $versao [formatarbytes $tamanho] $desc
		incr i
	}
	unset lista
	set cnome 4
	set ctam 7
	set cver 6
	set cdesc 10

	set lista [lsort -integer [array names p]]

	foreach item $lista {
		lappend lista2 "[string length [lindex $p($item) 0]] $item"
	}
	set lista2 [lsort -integer -index 0 $lista2]
	unset lista
	foreach item $lista2 {
		lappend lista [lindex $item 1]
	}

	set contagem 1
	foreach item $lista {
		if {[string length [lindex $p($item) 0]]>$cnome} {set cnome [string length [lindex $p($item) 0]]}
		if {[string length [lindex $p($item) 1]]>$cver} {set cver [string length [lindex $p($item) 1]]}
		if {[string length [lindex $p($item) 2]]>$ctam} {set ctam [string length [lindex $p($item) 2]]}
		if {[string length [lindex $p($item) 3]]>$cdesc} {set cdesc [string length [lindex $p($item) 3]]}
		if {$contagem==$visiveis} {break}
		incr contagem
	}

	putnow "privmsg $chan :A mostrar [set res [llength $lista]; if {$res>$visiveis} {set a "$visiveis de $res"} {set a "$res"}] resultados"

	putnow "privmsg $chan :[format "\037%-*s  %-*s  %-*s  %-*s" $cnome "Nome" $cver "Versão" $ctam "Tamanho" [if {$cdesc>100} {set a 100} {set cdesc}] "Descrição"]"

	set contagem 1
	foreach item $lista {
		set tdesc ""
		set desc [lindex $p($item) 3]
		foreach palavra [split $desc] {
			if {[expr [string length $tdesc]+[string length $palavra]]<99} {
				append tdesc "$palavra "
			} else {
				if {[llength $lista]>1} {
					append tdesc "…"
				}
				break
			}
		}
		set desc [string range $desc [string length $tdesc] end]

		putnow "privmsg $chan :[subst [regsub -all -nocase $text [format "%-*s  %-*s  %*s  %-*s" $cnome [lindex $p($item) 0] $cver [lindex $p($item) 1] $ctam [lindex $p($item) 2] 100 $tdesc] {\\037&\\037}]]"
		if {[llength $lista]==1 && $desc!=""} {
			set tdesc ""
			foreach palavra [split $desc] {
				if {[expr [string length $tdesc]+[string length $palavra]]<99} {
					append tdesc "$palavra "
				} else {
					putnow "privmsg $chan :[subst [regsub -all -nocase $text [format "%*s  %-*s" [expr $cnome+$cver+$ctam+4] "»" 100 $tdesc] {\\037&\\037}]]"
					set tdesc "$palavra "
				}
			}
			if {$tdesc!=""} {
				putnow "privmsg $chan :[subst [regsub -all -nocase $text [format "%*s  %-*s" [expr $cnome+$cver+$ctam+4] "»" 100 $tdesc] {\\037&\\037}]]"
			}

		}

		if {$contagem>=$visiveis} {break}
		incr contagem
	}

	if {$res>$visiveis} {
		set out "Outros: "
		set pponto 5
		foreach indx [lrange $lista 5 end] {
			if {[expr [string length $out]+[string length [lindex $p($indx) 0]]]<400} {
				lappend out [lindex $p($indx) 0]
				incr pponto
			} else {
				append out " (e mais [expr [llength $lista]-$pponto+1] pacote(s))"
				break
			}
		}
		putnow "privmsg $chan :$out"
	}
}

proc tp:apk {quem canal text} {
	switch [string tolower [lindex [split $text] 0]] {	
		"update"	{apkupdate $canal}
		"upgrade"	{apkupgrade $canal}
		"search"	{apksearch $canal [string trim [string range $text 7 end]]}
		default {
			putnow "PRIVMSG $canal :\002UPDATE\002  -> Obter listas de pacotes"
			putnow "PRIVMSG $canal :\002UPGRADE\002 -> Instala os pacotes actualizados"
			putnow "PRIVMSG $canal :\002SEARCH\002  -> Informação sobre um pacote"
		}
	}
}

bind apk tp:apk
set dscript(apk.tcl) "Usa o apk para actualizar a lista e os pacotes do OpenWRT"
