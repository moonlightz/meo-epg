if {[string match "This nickname is registered. Please choose a different nickname,*" $texto]} {
	sleep 1500
	putnow "PRIVMSG nickserv :identify <password>"
	sleep 1500
	foreach c $lcanais {
		putnow "JOIN $c"
	}
	unset c
	set nid 1
}

set dscript(idjoin.tcl) "Auto-identifica o bot perante o Nickserv e faz entrar nos canais"
