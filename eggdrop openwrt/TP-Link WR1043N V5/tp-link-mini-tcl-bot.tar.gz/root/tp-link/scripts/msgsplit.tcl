set quem ""; set way ""; set canal ""; set texto ""
if {[string match ":*!*@* * * :*" $in]} {
	set espaco1 [string first " " $in]
	set espaco2 [string first " " $in $espaco1+1]
	set espaco3 [string first " :" $in $espaco2+1]
	set quem [string range $in 1 $espaco1-1]
	set uhost [lindex [split $quem "!"] 1]
	set quem [lindex [split $quem "!"] 0]
	set way [string range $in $espaco1+1 $espaco2-1]
	set canal [string range $in $espaco2+1 $espaco3-1]
	set texto [string range $in $espaco3+2 end]
	unset espaco1 espaco2 espaco3
}

if {$canal!="" && [string index $canal 0]!="#"} {set canal [lindex [split $quem "!"] 0]}

#putnow "privmsg kashinkoji :>$quem< >$way< >$canal< >$texto<"
set dscript(msgsplit.tcl) "Coloca a mensagem vinda do servidor de IRC em algumas variáveis"
