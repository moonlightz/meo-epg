proc tp:meobox {quem canal text} {
	global sckmeobox
	if {![info exists sckmeobox]} {
		source meoboxip
		if {[catch {set sckmeobox [socket $meoboxip 8082]} erro]} {
			putnow "privmsg $canal :Não foi possível estabelecer a ligação. A procurar automaticamente. Isto pode levar algum tempo..."
			for {set numero 64} {$numero<254} {incr numero} {
				if {![catch {set sckmeobox [socket 192.168.1.$numero 8082]} erro]} {
					putnow "privmsg $canal :Box encontrada em 192.168.1.$numero aparentemente. A guardar este ip..."
					set fp [open meoboxip w+]
					puts $fp "set meoboxip \"192.168.1.$numero\""
					close $fp
					source meoboxip
					break
				}
			}
		}
		set shello [gets $sckmeobox]
		if {$shello=="hello"} {
			putnow "PRIVMSG $canal :Ligação estabelecida."
		} else {
			putnow "PRIVMSG $canal :Falha ao ligar."
		}
	}
	set text [string trim $text]
	if {$text==""} {return}
	if {$text=="ajuda"} {
		putnow "PRIVMSG $canal :listar          Lista por número\nlistar2         Lista por botão\nadic num botao  Adiciona um botão\nrem num         Remove um botão"
		return
	}

	if {[string range $text 0 3]=="key="} {
		set out "[string map {"!" "\n"} $text]\n"
		set text ""
	}
	if {$text=="sair"} {
		if {[catch {puts $sckmeobox "quit=\n"} erro]} {
			putnow "PRIVMSG $canal :Ocorreu um erro: $erro\nTente outra vez."
			unset sckmeobox
			return
		}
		flush $sckmeobox
		putnow "PRIVMSG $canal :[gets $sckmeobox]"
		close $sckmeobox
		unset sckmeobox
		return
	}

	set fp [open meobox.txt r]
	set mdb [read $fp]
	close $fp

	foreach cmd [split $text "|"] {
	foreach linha [split $mdb "\n"] {
		foreach {key mtext} [split $linha "\t"] {
			if {$text=="listar"} {lappend listabotoes "$key $mtext"}
			if {$text=="listar2"} {lappend listabotoes "$mtext $key"}
		}
		if {$cmd==$mtext} {set out "key=$key\n"; set text ""; break}
	}

	if {$text=="listar" || $text=="listar2"} {
		putnow "PRIVMSG $canal :Lista de botões atribuidos:"
		putnow "PRIVMSG $canal :[colunizar [lsort $listabotoes] 8]"
		return
	}

	if {[lindex $text 0]=="adic"} {
		set tadic [string range $text 5 end]
		if {$tadic==""} {
			putnow "PRIVMSG $canal :Nada para inserir. Falta número do botão e o nome."
		} else {
			set fdb [open meobox.txt a+]
			puts $fdb [string map {" " "\t"} $tadic]
			close $fdb
			putnow "PRIVMSG $canal :Adicionado."
		}
		return
	}

	if {[lindex $text 0]=="rem"} {
		set trem [string range $text 4 end]
		if {$trem==""} {
			putnow "PRIVMSG $canal :Falta o número."
			return
		}
		set prem [string first "$trem\t" $mdb]
		if {$prem<0} {
			putnow "PRIVMSG $canal :Não encontrado."
		} else {
			set fdb [open meobox.txt w+]
			puts -nonewline $fdb [string replace $mdb $prem [string first "\n" $mdb $prem]]
			close $fdb
			putnow "PRIVMSG $canal :Removido."
		}
		return
	}

	foreach carac [split $text {}] {
		switch $carac {
			0 	{append out "key=48\n"}
			1	{append out "key=49\n"}
			2	{append out "key=50\n"}
			3	{append out "key=51\n"}
			4	{append out "key=52\n"}
			5	{append out "key=53\n"}
			6	{append out "key=54\n"}
			7	{append out "key=55\n"}
			8	{append out "key=56\n"}
			9	{append out "key=57\n"}
		}
	}
	if {[info exists out]} {
		
		if {[catch {puts $sckmeobox $out} erro]} {
			putnow "PRIVMSG $canal :Ocorreu um erro: $erro\nTente outra vez."
			unset sckmeobox
			return
		}
		flush $sckmeobox
		lappend mresp [gets $sckmeobox]
		if {[string first "key=36" $out]>=0} {sleep 2000}
		unset out
		continue
	
	}
	putnow "PRIVMSG $canal :Não reconhecido. --> \002ajuda\002"
	}
	putnow "PRIVMSG $canal :$mresp"
}

bind meobox tp:meobox
set dscript(meobox.tcl) "meo"
