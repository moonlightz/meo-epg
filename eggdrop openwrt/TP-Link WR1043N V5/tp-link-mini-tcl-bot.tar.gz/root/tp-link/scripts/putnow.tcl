proc putnow {textoaenviar} {
	if {[string toupper [string range $textoaenviar 0 7]]=="PRIVMSG "} {
		set prmsg [string range $textoaenviar 0 [string first ":" $textoaenviar]]
		set strmt [list "\n" "\n$prmsg"]
		set textoaenviar [string map $strmt $textoaenviar]
	}

	set	icount 0
	foreach linha [split $textoaenviar "\n"] {
		incr icount
		if {$icount>5} {sleep 1500}
		puts $::fd $linha
		flush $::fd
	}
}
set dscript(putnow.tcl) "Mecanismo de envio"
