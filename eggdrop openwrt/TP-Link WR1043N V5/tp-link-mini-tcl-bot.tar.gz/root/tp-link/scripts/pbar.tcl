proc pbardraw {comprimento valor corbarra corfundo cortexto ptext} {
	set mypbarpbcol1 [expr $comprimento * $valor /100 ]
	set mypbarpbcol2 [expr $comprimento - $mypbarpbcol1]
	set mypbart "-"
	for {set i 1} {$i <= $comprimento} {incr i} {
		lappend mypbart "_"
	}
	set mypbartlength [string length $ptext]
	if {$mypbartlength > $comprimento} {
		set ptext [lrange $ptext 0 [expr $comprimento-2]]
		set mypbartlength [string length $ptext]
	}
	#posicao do texto na barra
	set mypbarpos [expr {round($comprimento/2)-round($mypbartlength/2)+1}]

	if {$mypbarpos<=1} {set mypbarpos "1"}
	for {set i 0} {$i < $mypbartlength} {incr i} {
		set j [expr $mypbarpos + $i]
		if {$j>$comprimento} {break}
		lset mypbart $j "[string range $ptext $i $i]"
	}
	for {set i 1} {$i <= $comprimento} {incr i} {
		if {[lindex $mypbart $i] =="_"} {
			if {$i <= $mypbarpbcol1} {
				lset mypbart $i "\003$corbarra,$corbarra[lindex $mypbart $i]"
			} else {
				lset mypbart $i "\003$corfundo,$corfundo[lindex $mypbart $i]"
			}
		} else {
			if {$i <= $mypbarpbcol1} {
				lset mypbart $i "\003$cortexto,$corbarra\026\026[lindex $mypbart $i]"
			} else {
				lset mypbart $i "\003$cortexto,$corfundo\026\026[lindex $mypbart $i]"
			}
		}
	}
	for {set i $comprimento} {$i>1} {incr i -1} {
		set mypbarcase1 [lindex $mypbart [expr $i-1]]
		set mypbarcase2 [lindex $mypbart $i]
		if {[string range $mypbarcase1 0 end-1]==[string range $mypbarcase2 0 end-1]} {
			lset mypbart $i [string range $mypbarcase2 end end]
		}
	}
	return "[string range [join $mypbart ""] 1 end]\003"
}

set dscript(pbar.tcl) "Barra de progresso"
