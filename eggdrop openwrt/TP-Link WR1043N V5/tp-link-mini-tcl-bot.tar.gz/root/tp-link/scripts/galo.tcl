proc mostrargalo {canal texto} {
	global gg
	foreach item [lsort -integer [array names gg]] {
		switch $gg($item) {
			"X"	{append grelhaout "\0030,7 ❌ \003"}
			"O" {append grelhaout "\0030,47 ⁣🔵 \003"}
			"A" {append grelhaout "\0034,0 ❌ \003"}
			"B" {append grelhaout "\00312,0 🔵 \003"}
			"1" {append grelhaout " ➊ "}
			"2" {append grelhaout " ➋ "}
			"3" {append grelhaout " ➌ "}
			"4" {append grelhaout " ➍ "}
			"5" {append grelhaout " ➎ "}
			"6" {append grelhaout " ➏ "}
			"7" {append grelhaout " ➐ "}
			"8" {append grelhaout " ➑ "}
			"9" {append grelhaout " ➒ "}
		}
		if {$item==3} {append grelhaout "\n"}
		if {$item==6} {append grelhaout " [string trim $texto]\n"}
	}
	putnow "privmsg $canal :$grelhaout"
}

proc checkgalo {} {
	global gg jogadorA jogadorB galoway
	foreach item $galoway {
		foreach coord {{1 2 3} {4 5 6} {7 8 9} {1 4 7} {2 5 8} {3 6 9} {1 5 9} {3 5 7}} { 
			if {$item==$gg([lindex $coord 0]) && $gg([lindex $coord 0])==$gg([lindex $coord 1]) && $gg([lindex $coord 1])==$gg([lindex $coord 2])} {
				foreach i $coord {
					if {$item=="X"} {set gg($i) "A"}
					if {$item=="O"} {set gg($i) "B"}
				}
				if {$item=="X"} {return $jogadorA}
				if {$item=="O"} {return $jogadorB}
			}
		}
	}
	for {set idx 1} {$idx<=10} {incr idx} {
		if {$idx==10} {return "<empate>"}
		if {[string is digit $gg($idx)]} {
			return ""
		}
	}
}

proc botjogou {jAnum} {
	global gg galoway
	foreach item $galoway {
		if {$gg(1)==$item && $gg(1)==$gg(2) && [string is digit $gg(3)]} {set gg(3) "O"; return "3"}
		if {$gg(4)==$item && $gg(4)==$gg(5) && [string is digit $gg(6)]} {set gg(6) "O"; return "6"}
		if {$gg(7)==$item && $gg(7)==$gg(8) && [string is digit $gg(9)]} {set gg(9) "O"; return "9"}

		if {$gg(2)==$item && $gg(2)==$gg(3) && [string is digit $gg(1)]} {set gg(1) "O"; return "1"}
		if {$gg(5)==$item && $gg(5)==$gg(6) && [string is digit $gg(4)]} {set gg(4) "O"; return "2"}
		if {$gg(8)==$item && $gg(8)==$gg(9) && [string is digit $gg(7)]} {set gg(7) "O"; return "3"}

		if {$gg(1)==$item && $gg(1)==$gg(4) && [string is digit $gg(7)]} {set gg(7) "O"; return "7"}
		if {$gg(2)==$item && $gg(2)==$gg(5) && [string is digit $gg(8)]} {set gg(8) "O"; return "8"}
		if {$gg(3)==$item && $gg(3)==$gg(6) && [string is digit $gg(9)]} {set gg(9) "O"; return "9"}

		if {$gg(4)==$item && $gg(4)==$gg(7) && [string is digit $gg(1)]} {set gg(1) "O"; return "1"}
		if {$gg(5)==$item && $gg(5)==$gg(8) && [string is digit $gg(2)]} {set gg(2) "O"; return "7"}
		if {$gg(6)==$item && $gg(6)==$gg(9) && [string is digit $gg(3)]} {set gg(3) "O"; return "3"}

		if {$gg(1)==$item && $gg(1)==$gg(9) && [string is digit $gg(5)]} {set gg(5) "O"; return "5"}
		if {$gg(1)==$item && $gg(1)==$gg(5) && [string is digit $gg(9)]} {set gg(9) "O"; return "9"}
		if {$gg(5)==$item && $gg(5)==$gg(9) && [string is digit $gg(1)]} {set gg(1) "O"; return "1"}

		if {$gg(3)==$item && $gg(3)==$gg(5) && [string is digit $gg(7)]} {set gg(7) "O"; return "7"}
		if {$gg(3)==$item && $gg(3)==$gg(7) && [string is digit $gg(5)]} {set gg(5) "O"; return "5"}
		if {$gg(5)==$item && $gg(5)==$gg(7) && [string is digit $gg(3)]} {set gg(3) "O"; return "3"}

		if {$gg(1)==$item && $gg(1)==$gg(7) && [string is digit $gg(4)]} {set gg(4) "O"; return "4"}
		if {$gg(2)==$item && $gg(2)==$gg(8) && [string is digit $gg(5)]} {set gg(5) "O"; return "5"}
		if {$gg(3)==$item && $gg(3)==$gg(9) && [string is digit $gg(6)]} {set gg(6) "O"; return "6"}

		if {$gg(1)==$item && $gg(1)==$gg(3) && [string is digit $gg(2)]} {set gg(2) "O"; return "2"}
		if {$gg(4)==$item && $gg(4)==$gg(6) && [string is digit $gg(5)]} {set gg(5) "O"; return "5"}
		if {$gg(7)==$item && $gg(7)==$gg(9) && [string is digit $gg(8)]} {set gg(8) "O"; return "8"}
	}

	while (1) {
		set rnd [expr int(rand()*9)+1]
		if {[string is digit $gg($rnd)] && $rnd!=$jAnum} {
			set gg($rnd) "O"
			return $rnd
		}	
	}
}

proc numerosporjogar {} {
	global gg
	for {set idx 1} {$idx<=9} {incr idx} {
		if {[string is digit $gg($idx)]} {
			return "sim"
		}
	}
	return "nao"
}

proc tp:galo {quem canal text} {
	global galorunning gg jogadorA jogadorB galoway
	set text [string trim $text]
	if {![info exists galorunning]} {
		set galorunning "nao"
	}
	if {$galorunning=="nao"} {
		if {$text!=""} {
			putnow "privmsg $canal :O jogo não está a decorrer. Tente só \002!galo\002."
			return
		}
		for {set i 1} {$i<=9} {incr i} {
			set gg($i) $i
		}
		if {[expr int(rand()*100)+1]>50} {
			set gg([expr int(rand()*9)+1]) "O"
			set galoway "O X"
			set exttext "- TP-Link quer jogar primeiro."
		} else {
			set galoway "X O"
			set exttext ""
		}
		set jogadorA $quem
		set jogadorB "TP-Link"
		mostrargalo $canal "Novo Jogo do Galo $exttext"
		set galorunning "sim"
	} else {
		if {$text=="stop"} {
			unset gg galorunning jogadorA jogadorB
			putnow "privmsg $canal :$quem parou o jogo."
			return
		}
		if {$text==""} {
			putnow "privmsg $canal :[mostrargalo $canal "$jogadorA está a jogar contra o $jogadorB"]"
			return
		}
		if {$text ni {1 2 3 4 5 6 7 8 9}} {
			putnow "privmsg $canal :Isso não é válido."
			return
		}
		switch $gg($text) {
			"X" {putnow "privmsg $canal :Já jogou nesse número. Jogue outro número."; seturn}
			"O" {putnow "privmsg $canal :O adversário já jogou esse número. Jogue outro número."; return}
		}
		set rescheckgalo ""
		set jBnum ""
		if {[lindex $galoway 0]=="X"} {
			set gg($text) "X"
			set rescheckgalo [checkgalo]
			if {$rescheckgalo==""} {
				if {[numerosporjogar]=="sim"} {
					set jBnum [botjogou $text]
				}
				set rescheckgalo [checkgalo]
			}
		}
		if {[lindex $galoway 0]=="O"} {
			set jBnum [botjogou $text]
			set rescheckgalo [checkgalo]
			if {$rescheckgalo==""} {
				if {[numerosporjogar]=="sim"} {
					set gg($text) "X"
					set rescheckgalo [checkgalo]
				}
			}
		}

		set msgvencedor ""
		if {$rescheckgalo==$jogadorA || $rescheckgalo==$jogadorB} {
			set msgvencedor "$rescheckgalo ganhou!"
		} 
		if {$rescheckgalo=="<empate>"} {
			set msgvencedor "Empate! Ninguém ganhou!"
		}
		mostrargalo $canal "[if {$jBnum!=""} {set a "$jogadorB jogou o $jBnum."}] $msgvencedor"
		if {$rescheckgalo!=""} {
			unset gg galorunning jogadorA jogadorB
			return
		}
		 
		
		
	}
}

bind !galo tp:galo

set dscript(galo.tcl) "Jogo do Galo"

